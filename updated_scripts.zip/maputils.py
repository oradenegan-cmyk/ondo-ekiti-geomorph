"""Shared cartographic helpers: graticule labelled on all four sides, split north arrow,
boxed scale bar, boxed legend and a neat line around the whole figure."""
import os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource
from matplotlib.patches import Polygon, Rectangle, FancyBboxPatch
from pyproj import Transformer

TO_UTM = Transformer.from_crs("EPSG:4326", "EPSG:32631", always_xy=True)
TO_GEO = Transformer.from_crs("EPSG:32631", "EPSG:4326", always_xy=True)

SERIF = ["Liberation Serif", "Times New Roman", "DejaVu Serif"]
STYLE = {
    "font.family": "serif", "font.serif": SERIF, "mathtext.fontset": "stix",
    "font.size": 8, "axes.titlesize": 9, "axes.labelsize": 8,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7, "axes.linewidth": 0.6,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "figure.dpi": 150, "savefig.dpi": int(os.environ.get("FIG_DPI", "400")), "savefig.bbox": "tight",
    "savefig.pad_inches": 0.08, "axes.grid": False, "pdf.fonttype": 42,
}
INK = "#000000"; MUTED = "#555555"; GRID = "#9a9a9a"; CHART_GRID = "#d9d9d9"


def apply_style():
    mpl.rcParams.update(STYLE)


def extent(transform, shape):
    h, w = shape
    return [transform.c, transform.c + transform.a * w, transform.f + transform.e * h, transform.f]


def hillshade(z, cellsize, az=315, alt=40, vert_exag=3):
    ls = LightSource(azdeg=az, altdeg=alt)
    zf = np.where(np.isfinite(z), z, np.nanmin(z))
    hs = ls.hillshade(zf, vert_exag=vert_exag, dx=cellsize, dy=cellsize)
    return np.where(np.isfinite(z), hs, np.nan)


def fmt_deg(v, hemi):
    d = int(np.floor(abs(v) + 1e-9)); m = int(round((abs(v) - d) * 60))
    if m == 60:
        d += 1; m = 0
    return f"{d}°{m:02d}′{hemi}"


def _crossing(xs, ys, coord, value):
    """Interpolate where a polyline crosses x=value (coord='x') or y=value (coord='y')."""
    a = xs if coord == "x" else ys
    b = ys if coord == "x" else xs
    s = np.sign(a - value)
    i = np.where(np.diff(s) != 0)[0]
    if i.size == 0:
        return None
    i = i[0]
    t = (value - a[i]) / (a[i + 1] - a[i])
    return b[i] + t * (b[i + 1] - b[i])


def graticule(ax, ext, step=0.5, label=True, color=GRID, lw=0.5, fontsize=8, sides="tblr"):
    """Lon/lat lines on a UTM map; labels outside the frame on every side, latitude labels
    rotated to run along the left and right edges (as in conventional thesis maps)."""
    x0, x1, y0, y1 = ext
    corners = [TO_GEO.transform(x, y) for x, y in [(x0, y0), (x0, y1), (x1, y0), (x1, y1)]]
    lons = [c[0] for c in corners]; lats = [c[1] for c in corners]
    lo_rng = np.arange(np.floor(min(lons) / step) * step, max(lons) + step, step)
    la_rng = np.arange(np.floor(min(lats) / step) * step, max(lats) + step, step)
    t = np.linspace(min(lats) - 1, max(lats) + 1, 400)
    off = 0.008
    for lo in lo_rng:
        xs, ys = TO_UTM.transform(np.full_like(t, lo), t)
        ax.plot(xs, ys, color=color, lw=lw, zorder=1.5)
        if label:
            for side, yv, va, dy in (("b", y0, "top", -off), ("t", y1, "bottom", off)):
                if side not in sides:
                    continue
                xc = _crossing(np.asarray(xs), np.asarray(ys), "y", yv)
                if xc is not None and x0 < xc < x1:
                    ax.text((xc - x0) / (x1 - x0), (0 if side == "b" else 1) + dy, fmt_deg(lo, "E"),
                            transform=ax.transAxes, ha="center", va=va, fontsize=fontsize, color=INK, clip_on=False)
    t = np.linspace(min(lons) - 1, max(lons) + 1, 400)
    for la in la_rng:
        xs, ys = TO_UTM.transform(t, np.full_like(t, la))
        ax.plot(xs, ys, color=color, lw=lw, zorder=1.5)
        if label:
            for side, xv, ha, dx in (("l", x0, "right", -off), ("r", x1, "left", off)):
                if side not in sides:
                    continue
                yc = _crossing(np.asarray(xs), np.asarray(ys), "x", xv)
                if yc is not None and y0 < yc < y1:
                    ax.text((0 if side == "l" else 1) + dx, (yc - y0) / (y1 - y0), fmt_deg(la, "N"),
                            transform=ax.transAxes, ha=ha, va="center", rotation=90, fontsize=fontsize,
                            color=INK, clip_on=False, rotation_mode="anchor" if False else "default")
    ax.set_xlim(x0, x1); ax.set_ylim(y0, y1)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel(""); ax.set_ylabel("")
    for s in ax.spines.values():
        s.set_visible(True); s.set_linewidth(1.0); s.set_color(INK)


def north_arrow(ax, loc=(0.92, 0.84), size=0.075, fontsize=13):
    """Split (half black, half white) north arrow with N above; grid north, UTM 31N
    (grid convergence < 1° over the area)."""
    cx, cy = loc
    w = size * 0.32
    tip = (cx, cy + size); base_l = (cx - w, cy); base_r = (cx + w, cy); notch = (cx, cy + size * 0.28)
    ax.add_patch(Polygon([tip, base_l, notch], closed=True, transform=ax.transAxes, facecolor=INK,
                         edgecolor=INK, lw=0.8, zorder=20))
    ax.add_patch(Polygon([tip, notch, base_r], closed=True, transform=ax.transAxes, facecolor="white",
                         edgecolor=INK, lw=0.8, zorder=20))
    ax.text(cx, cy + size + 0.012, "N", transform=ax.transAxes, ha="center", va="bottom",
            fontsize=fontsize, fontweight="bold", color=INK, zorder=20)


def scalebar(ax, ticks_km=(0, 10, 20, 40), loc=(0.03, 0.035), fontsize=8, box=True, bar_h=0.010):
    """Boxed alternating scale bar, e.g. 0 10 20 40 km, in a white panel with a black border."""
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    W = x1 - x0; Hh = y1 - y0
    bx = x0 + loc[0] * W + 0.03 * W; by = y0 + loc[1] * Hh + 0.018 * Hh
    L = ticks_km[-1] * 1000
    if box:
        ax.add_patch(Rectangle((x0 + loc[0] * W, y0 + loc[1] * Hh), L + 0.11 * W, 0.062 * Hh,
                               facecolor="white", edgecolor=INK, lw=0.9, zorder=18))
    h = bar_h * Hh
    for i, (a_, b_) in enumerate(zip(ticks_km[:-1], ticks_km[1:])):
        ax.add_patch(Rectangle((bx + a_ * 1000, by), (b_ - a_) * 1000, h, facecolor=INK if i % 2 == 0 else "white",
                               edgecolor=INK, lw=0.7, zorder=19))
    for tk in ticks_km:
        ax.text(bx + tk * 1000, by + h + 0.006 * Hh, f"{tk}", ha="center", va="bottom", fontsize=fontsize,
                color=INK, zorder=20)
    ax.text(bx + L + 0.012 * W, by + h / 2, "km", ha="left", va="center", fontsize=fontsize, color=INK, zorder=20)


def boxed_legend(ax, handles, loc="lower right", title=None, fontsize=8, ncol=1, bbox=None):
    lg = ax.legend(handles=handles, loc=loc, title=title, fontsize=fontsize, title_fontsize=fontsize + 0.5,
                   frameon=True, fancybox=False, edgecolor=INK, framealpha=1, ncol=ncol,
                   bbox_to_anchor=bbox, borderpad=0.7, handlelength=2.2, handleheight=1.0)
    lg.get_frame().set_linewidth(0.9)
    if title:
        lg.get_title().set_fontweight("bold")
    lg.set_zorder(25)
    return lg


def neatline(fig, pad=0.006, lw=1.6):
    """Outer frame around the whole figure (drawn in figure coordinates)."""
    fig.patches.append(Rectangle((pad, pad), 1 - 2 * pad, 1 - 2 * pad, transform=fig.transFigure,
                                 fill=False, edgecolor=INK, lw=lw, zorder=100))
