"""
10_geology.py: lithological control on terrain units (Paper A) and on river profiles (Paper B).

Input: the combined Ondo-Ekiti geology mosaic (data/raw/geology/OndoEkiti_geology_mosaic_RGB_WGS84.tif),
an RGBA raster on a 1 arc-second WGS 84 grid in which every unit has a single legend colour
(data/raw/geology/OndoEkiti_geology_legend.csv). Sources: NGSA Geological and Mineral Resources Map of
Ekiti State (2022, 1:250 000) within Ekiti; an Ondo State compilation (~325 m pixels) elsewhere.

1. Decode colours to unit ids; reproject (nearest neighbour) to the 90 m and 30 m UTM 31N analysis grids.
2. Group units into five lithological groups of contrasting resistance.
3. Paper A: area cross-tabulation of terrain units and systems against lithology; enrichment ratios;
   Cramer's V on all cells and a chi-square test on a 5 km systematic subsample (to limit spatial
   autocorrelation); low-slope (< 2 deg) elevation peaks recomputed within single lithological groups.
4. Paper B: distance from knickpoints to the nearest lithological-group contact, tested against random
   channel nodes (A >= 5 km2) by Monte Carlo; ksn by lithological group; basin lithology fractions and
   their relation to concavity.

Usage: python -I scripts/10_geology.py --root .
"""
import argparse, os, json, csv
import numpy as np, rasterio
from rasterio.warp import reproject, Resampling
from scipy import stats, ndimage
from scipy.signal import find_peaks

ap = argparse.ArgumentParser(); ap.add_argument("--root", default=".")
ap.add_argument("--contact_m", type=float, default=500.0)
a = ap.parse_args(); R = os.path.abspath(a.root)
P = os.path.join(R, "data/processed"); T = os.path.join(R, "outputs/tables"); G = os.path.join(R, "data/raw/geology")

# ---------------------------------------------------------------- 1. decode and regrid
L = list(csv.DictReader(open(os.path.join(G, "OndoEkiti_geology_legend.csv"), encoding="utf-8")))
GROUPS = {  # 1 granitoid; 2 migmatite-gneiss; 3 schist; 4 quartzite; 5 sedimentary
    "OGp": 1, "OGu": 1, "OGf": 1, "OGm": 1, "OGd": 1, "OGh": 1, "OGCh": 1, "P": 1,
    "M": 2, "GG": 2, "Eg": 2,
    "Su": 3, "Ps": 3, "e": 3,
    "Sf": 4, "Qs": 4, "QS": 4, "qS": 4,
    "Ajst": 5, "Imsh": 5, "OAlgs": 5, "Mcst": 5, "Nsh": 5, "Issh": 5, "Bnst": 5, "Al": 5}
GNAMES = {1: "Older Granite suite and charnockite", 2: "Migmatite and gneiss", 3: "Schist",
          4: "Quartzite and quartz schist", 5: "Cretaceous to Recent sediments"}
GSHORT = {1: "Granitoid", 2: "Migmatite–gneiss", 3: "Schist", 4: "Quartzite", 5: "Sedimentary"}
code_of = {int(l["id"]): l["code"] for l in L}
with rasterio.open(os.path.join(G, "OndoEkiti_geology_mosaic_RGB_WGS84.tif")) as s:
    rgba = s.read(); src_t = s.transform; src_crs = s.crs
key = rgba[0].astype(np.int64) * 65536 + rgba[1].astype(np.int64) * 256 + rgba[2]
ids = np.zeros(key.shape, np.uint8)
for l in L:
    ids[key == int(l["R"]) * 65536 + int(l["G"]) * 256 + int(l["B"])] = int(l["id"])
ids[rgba[3] == 0] = 0
assert (ids[rgba[3] > 0] > 0).all(), "undecoded colours in mosaic"


def regrid(ref):
    with rasterio.open(os.path.join(P, ref)) as r:
        out = np.zeros(r.shape, np.uint8); prof = r.profile
        reproject(ids, out, src_transform=src_t, src_crs=src_crs, dst_transform=r.transform, dst_crs=r.crs,
                  resampling=Resampling.nearest, src_nodata=0, dst_nodata=0)
    prof.update(dtype="uint8", nodata=0, count=1, compress="deflate")
    return out, prof


lut = np.zeros(256, np.uint8)
for i, c in code_of.items():
    lut[i] = GROUPS[c]
geo90, p90 = regrid("dem_utm90.tif"); geo30, p30 = regrid("dem_utm30.tif")
for arr, prof, name in [(geo90, p90, "geology90"), (geo30, p30, "geology30")]:
    with rasterio.open(os.path.join(P, name + ".tif"), "w", **prof) as d: d.write(arr, 1)
    with rasterio.open(os.path.join(P, name.replace("geology", "lithgroup") + ".tif"), "w", **prof) as d: d.write(lut[arr], 1)
lg90 = lut[geo90]; lg30 = lut[geo30]
res = dict(group_members={GSHORT[g]: [c for c, gg in GROUPS.items() if gg == g] for g in GNAMES}, group_names=GNAMES)

# ---------------------------------------------------------------- 2. Paper A
rd = lambda f: rasterio.open(os.path.join(P, f)).read(1)
units = rd("units90.tif"); systems = rd("systems90.tif"); z90 = rd("dem_utm90.tif"); slope = rd("slope90.tif")
valid = (units > 0) & (lg90 > 0)
res["coverage_frac_of_terrain_cells"] = float(valid.sum() / (units > 0).sum())
cell_km2 = 0.0081


def crosstab(cls, ncls):
    M = np.zeros((ncls, 5))
    for i in range(1, ncls + 1):
        for g in range(1, 6):
            M[i - 1, g - 1] = np.sum(valid & (cls == i) & (lg90 == g))
    return M


def cramers_v(M):
    chi2 = stats.chi2_contingency(M, correction=False)[0]
    return float(np.sqrt(chi2 / (M.sum() * (min(M.shape) - 1))))


rows = []
for name, cls, n in [("units", units, 6), ("systems", systems, 3)]:
    M = crosstab(cls, n)
    # 5 km systematic subsample (every 56th row and column of the 90 m grid ~ 5.04 km)
    sub = np.zeros_like(valid); sub[::56, ::56] = True
    Ms = np.zeros((n, 5))
    for i in range(1, n + 1):
        for g in range(1, 6):
            Ms[i - 1, g - 1] = np.sum(sub & valid & (cls == i) & (lg90 == g))
    keep_r = Ms.sum(1) > 0; keep_c = Ms.sum(0) > 0
    chi = stats.chi2_contingency(Ms[keep_r][:, keep_c], correction=False)
    res[f"cramers_v_{name}_lithology"] = cramers_v(M)
    res[f"cramers_v_{name}_lithology_5km"] = dict(V=cramers_v(Ms[keep_r][:, keep_c]), chi2=float(chi[0]), dof=int(chi[2]),
                                                  p=float(chi[1]), n=int(Ms.sum()))
    exp_share = M.sum(0) / M.sum()           # share of each lithology in the whole area
    for i in range(n):
        for g in range(5):
            rows.append(dict(level=name, cls=i + 1, group=g + 1, area_km2=round(M[i, g] * cell_km2, 1),
                             share_of_class=round(M[i, g] / M[i].sum(), 4),
                             enrichment=round((M[i, g] / M[i].sum()) / exp_share[g], 3)))
    res[f"{name}_lithology_matrix_km2"] = (M * cell_km2).round(1).tolist()
res["lithology_share_area"] = (crosstab(units, 6).sum(0) / valid.sum()).round(4).tolist()
with open(os.path.join(T, "terrain_lithology_crosstab.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

# mutual information: how much of the unit map is "explained" by lithology (normalised by unit entropy)
def nmi(M):
    p = M / M.sum(); pr = p.sum(1, keepdims=True); pc = p.sum(0, keepdims=True)
    nz = p > 0
    mi = np.sum(p[nz] * np.log(p[nz] / (pr @ pc)[nz]))
    hr = -np.sum(pr[pr > 0] * np.log(pr[pr > 0]))
    return float(mi / hr)
res["nmi_units_given_lithology"] = nmi(crosstab(units, 6))
res["nmi_systems_given_lithology"] = nmi(crosstab(systems, 3))
# for comparison: elevation bands (100 m) explain how much of the unit map?
zb = np.clip((z90 // 100).astype(int), 0, 7)
Mz = np.zeros((6, 8))
for i in range(1, 7):
    for b in range(8):
        Mz[i - 1, b] = np.sum(valid & (units == i) & (zb == b))
res["nmi_units_given_elev100"] = nmi(Mz)

# low-slope elevation peaks within single lithological groups (basement only, above 50 m)
grid = np.arange(0, 800, 1.0)
ls = valid & (slope < 2) & (z90 > -100)
kde_rows = {"elev": grid}
res["lowslope_peaks_by_group"] = {}
for g in (1, 2, 3, 4, 5):
    v = z90[ls & (lg90 == g)]
    if v.size < 500:
        continue
    vv = np.random.default_rng(3).choice(v, min(v.size, 60000), replace=False)
    d = stats.gaussian_kde(vv, bw_method=10 / vv.std())(grid)
    kde_rows[GSHORT[g]] = d
    pk, pr = find_peaks(d, prominence=0.05 * d.max())
    res["lowslope_peaks_by_group"][GSHORT[g]] = dict(n=int(v.size), peaks=[float(grid[i]) for i in pk],
                                                     prominence_rel=[float(p / d.max()) for p in pr["prominences"]])
np.savetxt(os.path.join(T, "lowslope_kde_by_lithology.csv"), np.column_stack(list(kde_rows.values())), delimiter=",",
           header=",".join(kde_rows.keys()), fmt="%.6g", comments="")
# share of the low-slope cells near each regional level that lie on each lithology
for Lv in (347, 546):
    m = ls & (np.abs(z90 - Lv) <= 30)
    res[f"level_{Lv}_lithology_share"] = [float(np.sum(m & (lg90 == g)) / m.sum()) for g in range(1, 6)]

# ---------------------------------------------------------------- 3. Paper B
ch = np.load(os.path.join(P, "channels.npz"))
with rasterio.open(os.path.join(P, "dem_utm30.tif")) as s:
    t30 = s.transform
cc = ((ch["x"] - t30.c) / t30.a).astype(int); rr = ((ch["y"] - t30.f) / t30.e).astype(int)
ch_lg = lg30[rr, cc]
# contacts between lithological groups; distance transform in metres
edge = np.zeros(lg30.shape, bool)
for sh in [(0, 1), (1, 0)]:
    a1 = lg30; a2 = np.roll(lg30, sh, axis=(0, 1))
    e = (a1 != a2) & (a1 > 0) & (a2 > 0)
    edge |= e
dist = ndimage.distance_transform_edt(~edge) * 30.0
ch_d = dist[rr, cc]
K = list(csv.DictReader(open(os.path.join(T, "knickpoints.csv"))))
kx = np.array([float(k["x"]) for k in K]); ky = np.array([float(k["y"]) for k in K])
kc = ((kx - t30.c) / t30.a).astype(int); kr = ((ky - t30.f) / t30.e).astype(int)
k_d = dist[kr, kc]; k_lg = lg30[kr, kc]
ktype = np.array([k["type"] for k in K])
pool = (ch["A"] >= 5e6) & (ch_lg > 0)
rng = np.random.default_rng(17)
res["contact"] = {}
for lab, m in [("all", np.ones(len(K), bool)), ("transient", ktype == "transient"), ("stationary", ktype != "transient")]:
    m = m & (k_lg > 0)
    obs = float(np.mean(k_d[m] <= a.contact_m))
    null = np.array([np.mean(rng.choice(ch_d[pool], m.sum(), replace=False) <= a.contact_m) for _ in range(10000)])
    res["contact"][lab] = dict(n=int(m.sum()), frac_within=obs, null_mean=float(null.mean()),
                               null_p95=float(np.percentile(null, 95)),
                               p_value=float((np.sum(null >= obs) + 1) / (null.size + 1)),
                               median_dist_m=float(np.median(k_d[m])))
res["contact_threshold_m"] = a.contact_m
# lithology at knickpoints vs channel nodes
res["kp_lithology_share"] = [float(np.mean(k_lg[k_lg > 0] == g)) for g in range(1, 6)]
res["node_lithology_share"] = [float(np.mean(ch_lg[pool] == g)) for g in range(1, 6)]
# knickpoints at the basement/sediment contact specifically
sed = lg30 == 5; base = (lg30 > 0) & (lg30 < 5)
bs_edge = (sed & ~np.roll(sed, 1, 0) & np.roll(base, 1, 0)) | (sed & ~np.roll(sed, 1, 1) & np.roll(base, 1, 1)) | \
          (base & np.roll(sed, 1, 0)) | (base & np.roll(sed, 1, 1))
dbs = ndimage.distance_transform_edt(~bs_edge) * 30.0
res["kp_within_contact_of_sediment_edge"] = int(np.sum(dbs[kr, kc] <= a.contact_m))
# ksn by lithological group
ksn = ch["ksn"]; good = np.isfinite(ksn) & (ch["A"] >= 1e6) & (ch_lg > 0)
res["ksn_by_lithology"] = {}
groups_ksn = []
for g in range(1, 6):
    v = ksn[good & (ch_lg == g)]
    groups_ksn.append(v[::25])
    res["ksn_by_lithology"][GSHORT[g]] = dict(n=int(v.size), median=float(np.median(v)), p25=float(np.percentile(v, 25)),
                                              p75=float(np.percentile(v, 75)), p05=float(np.percentile(v, 5)),
                                              p95=float(np.percentile(v, 95)))
kw = stats.kruskal(*groups_ksn)
N = sum(g.size for g in groups_ksn)
res["ksn_lithology_kruskal"] = dict(H=float(kw.statistic), p=float(kw.pvalue), n=int(N),
                                    epsilon2=float(kw.statistic / (N - 1)))
# same effect size for terrain systems, on the same thinned nodes, for comparison
with rasterio.open(os.path.join(P, "systems90.tif")) as s:
    sysr = s.read(1); t90 = s.transform
c9 = ((ch["x"] - t90.c) / t90.a).astype(int); r9 = ((ch["y"] - t90.f) / t90.e).astype(int)
sysn = sysr[np.clip(r9, 0, sysr.shape[0] - 1), np.clip(c9, 0, sysr.shape[1] - 1)]
gs = [ksn[good & (sysn == s_)][::25] for s_ in (1, 2, 3) if np.any(good & (sysn == s_))]
kw2 = stats.kruskal(*gs); N2 = sum(g.size for g in gs)
res["ksn_system_kruskal_same_nodes"] = dict(H=float(kw2.statistic), p=float(kw2.pvalue), n=int(N2),
                                            epsilon2=float(kw2.statistic / (N2 - 1)))
# within basement only: does ksn differ between granitoid and migmatite-gneiss when terrain system is held fixed?
res["ksn_granitoid_vs_migmatite_by_system"] = {}
for s_ in (2, 3):
    v1 = ksn[good & (ch_lg == 1) & (sysn == s_)]; v2 = ksn[good & (ch_lg == 2) & (sysn == s_)]
    if v1.size > 50 and v2.size > 50:
        mw = stats.mannwhitneyu(v1[::25], v2[::25])
        res["ksn_granitoid_vs_migmatite_by_system"][str(s_)] = dict(
            median_granitoid=float(np.median(v1)), median_migmatite=float(np.median(v2)),
            n_granitoid=int(v1.size), n_migmatite=int(v2.size), p_thinned=float(mw.pvalue))

# basin lithology fractions and concavity
basins = rd("basins30.tif")
B = list(csv.DictReader(open(os.path.join(T, "basins.csv"))))
brow = []
for b in B:
    bid = int(b["basin"])
    m = basins == bid
    lg = lg30[m]; lg = lg[lg > 0]
    fr = [float(np.mean(lg == g)) if lg.size else np.nan for g in range(1, 6)]
    brow.append(dict(basin=bid, theta=b["theta_best"], outlet_z=float(b["outlet_z"]), area_km2=float(b["area_km2"]),
                     mapped_frac=float(lg.size / m.sum()), **{GSHORT[g]: round(fr[g - 1], 3) for g in range(1, 6)}))
with open(os.path.join(T, "basin_lithology.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(brow[0].keys())); w.writeheader(); w.writerows(brow)
big = [r for r in brow if r["theta"] not in ("", "nan")]
th = np.array([float(r["theta"]) for r in big]); oz = np.array([r["outlet_z"] for r in big])
res["theta_vs_lithology"] = {}
for g in range(1, 6):
    f_ = np.array([r[GSHORT[g]] for r in big])
    if np.ptp(f_) > 0:
        rho = stats.spearmanr(th, f_)
        res["theta_vs_lithology"][GSHORT[g]] = dict(rho=float(rho.statistic), p=float(rho.pvalue),
                                                    upland_median=float(np.median(f_[oz > 250])),
                                                    low_median=float(np.median(f_[oz <= 250])))
# basement-only check: partial association of theta with outlet elevation controlling for sediment fraction
sedf = np.array([r["Sedimentary"] for r in big])
def resid(y, x):
    ry = stats.rankdata(y); rx = stats.rankdata(x)
    b_ = np.polyfit(rx, ry, 1); return ry - np.polyval(b_, rx)
pr = stats.pearsonr(resid(th, sedf), resid(oz, sedf))
res["partial_spearman_theta_outletz_given_sediment"] = dict(r=float(pr.statistic), p=float(pr.pvalue), n=int(th.size))
# ---------------------------------------------------------------- 4. basement-only checks
# the sedimentary cover coincides almost exactly with the coastal lowland, so association statistics are
# repeated on basement terrain only (lithological groups 1-4, terrain units 2-6)
bm = valid & (lg90 < 5) & (units >= 2)
Mb = np.array([[np.sum(bm & (units == i) & (lg90 == g)) for g in range(1, 5)] for i in range(2, 7)], float)
sub = np.zeros_like(bm); sub[::56, ::56] = True
Mbs = np.array([[np.sum(sub & bm & (units == i) & (lg90 == g)) for g in range(1, 5)] for i in range(2, 7)], float)
chi = stats.chi2_contingency(Mbs, correction=False)
res["basement_only"] = dict(cramers_v_units=cramers_v(Mb), nmi_units=nmi(Mb),
                            subsample_5km=dict(V=cramers_v(Mbs), chi2=float(chi[0]), dof=int(chi[2]), p=float(chi[1]), n=int(Mbs.sum())),
                            lith_share=(Mb.sum(0) / Mb.sum()).round(4).tolist(),
                            unit_share_by_lith=(Mb / Mb.sum(0, keepdims=True)).round(4).tolist(),
                            enrichment=((Mb / Mb.sum(1, keepdims=True)) / (Mb.sum(0) / Mb.sum())).round(3).tolist(),
                            matrix_km2=(Mb * cell_km2).round(1).tolist())
Mzb = np.array([[np.sum(bm & (units == i) & (zb == b)) for b in range(8)] for i in range(2, 7)], float)
res["basement_only"]["nmi_units_given_elev100"] = nmi(Mzb)
gb = [ksn[good & (ch_lg == g)][::25] for g in range(1, 5)]
kwb = stats.kruskal(*gb); Nb = sum(g.size for g in gb)
res["ksn_lithology_kruskal_basement"] = dict(H=float(kwb.statistic), p=float(kwb.pvalue), n=int(Nb), epsilon2=float(kwb.statistic / (Nb - 1)))
gsb = [ksn[good & (ch_lg < 5) & (sysn == s_)][::25] for s_ in (2, 3)]
kwsb = stats.kruskal(*gsb); Nsb = sum(g.size for g in gsb)
res["ksn_system_kruskal_basement"] = dict(H=float(kwsb.statistic), p=float(kwsb.pvalue), n=int(Nsb), epsilon2=float(kwsb.statistic / (Nsb - 1)))
# contact test sensitivity to the distance threshold
res["contact_sensitivity"] = {}
for thr in (250.0, 500.0, 1000.0):
    res["contact_sensitivity"][str(int(thr))] = {}
    for lab, m in [("transient", ktype == "transient"), ("stationary", ktype != "transient")]:
        m = m & (k_lg > 0); obs = float(np.mean(k_d[m] <= thr))
        null = np.array([np.mean(rng.choice(ch_d[pool], m.sum(), replace=False) <= thr) for _ in range(10000)])
        res["contact_sensitivity"][str(int(thr))][lab] = dict(n=int(m.sum()), frac_within=obs, null_mean=float(null.mean()),
                                                             null_q025=float(np.percentile(null, 2.5)), null_q975=float(np.percentile(null, 97.5)),
                                                             p_value=float((np.sum(null >= obs) + 1) / (null.size + 1)))
# ---------------------------------------------------------------- 5. lithology along the swath profiles
from pyproj import Transformer
to_utm = Transformer.from_crs("EPSG:4326", "EPSG:32631", always_xy=True)
SW = json.load(open(os.path.join(T, "swaths.json"), encoding="utf-8"))
with rasterio.open(os.path.join(P, "dem_utm90.tif")) as s:
    tr90 = s.transform
H_, W_ = lg90.shape
yy, xx = np.mgrid[0:H_, 0:W_]
X0 = tr90.c + (xx + 0.5) * tr90.a; Y0 = tr90.f + (yy + 0.5) * tr90.e
sw_out = {}
for nm, v in SW.items():
    (x1, y1), (x2, y2) = to_utm.transform(*v["start"]), to_utm.transform(*v["end"])
    L_ = np.hypot(x2 - x1, y2 - y1); ux, uy = (x2 - x1) / L_, (y2 - y1) / L_
    along = (X0 - x1) * ux + (Y0 - y1) * uy; across = -(X0 - x1) * uy + (Y0 - y1) * ux
    m = (units > 0) & (np.abs(across) <= v["half_width_km"] * 1000) & (along >= 0) & (along <= L_)
    bins = np.arange(0, L_ + 1000, 1000); bi = np.digitize(along[m], bins) - 1; ll = lg90[m]
    prof = []
    for b in range(len(bins) - 1):
        sel = bi == b
        if sel.sum() < 20:
            continue
        lv = ll[sel]; mapped = lv[lv > 0]
        prof.append(dict(dist_km=(bins[b] + 500) / 1000, mapped_frac=float(mapped.size / lv.size),
                         **{GSHORT[g]: (float(np.mean(mapped == g)) if mapped.size else None) for g in range(1, 6)},
                         lith_mode=(int(np.bincount(mapped, minlength=6)[1:].argmax() + 1) if mapped.size else 0)))
    sw_out[nm] = prof
json.dump(sw_out, open(os.path.join(T, "swath_lithology.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
pa = sw_out["A–A′"]
sedA = [(r["dist_km"], r["Sedimentary"]) for r in pa if r["Sedimentary"] is not None]
last_sed = max(d for d, f in sedA if f >= 0.5)
res["swathA_last_bin_sediment_majority_km"] = float(last_sed)
for lab, (d0, d1) in {"lower_riser_90_120": (90, 120), "upper_riser_190_210": (190, 210), "tread_130_190": (130, 190)}.items():
    rr_ = [r for r in pa if d0 <= r["dist_km"] <= d1 and r["mapped_frac"] > 0]
    res[f"swathA_{lab}_lith_share"] = {GSHORT[g]: float(np.mean([r[GSHORT[g]] for r in rr_])) for g in range(1, 6)}
json.dump(res, open(os.path.join(T, "geology_stats.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False, default=float)
print(json.dumps(res, indent=1, ensure_ascii=False, default=float))
