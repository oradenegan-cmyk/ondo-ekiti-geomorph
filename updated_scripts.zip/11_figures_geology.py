"""
11_figures_geology.py: lithology figures for Papers A and B (run after 10_geology.py).
  paperA/FigA_lithology_map        lithological groups of the Ondo-Ekiti geology mosaic
  paperA/FigA_lithology_terrain    (a) enrichment of terrain units by lithology on basement terrain;
                                   (b) low-slope elevation density within granitoid and migmatite-gneiss
  paperB/FigB_lithology_channels   (a) ksn by lithological group; (b) knickpoints near lithological contacts
Usage: python -I scripts/11_figures_geology.py --root .
"""
import argparse, os, sys, json, csv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, rasterio, geopandas as gpd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.lines import Line2D
import maputils as mu

ap = argparse.ArgumentParser(); ap.add_argument("--root", default="."); a = ap.parse_args()
R = os.path.abspath(a.root); P = os.path.join(R, "data/processed"); T = os.path.join(R, "outputs/tables")
FR_ = os.environ.get("FIG_ROOT", "outputs/figures")
FA = os.path.join(R, FR_, "paperA"); FB = os.path.join(R, FR_, "paperB")
os.makedirs(FA, exist_ok=True); os.makedirs(FB, exist_ok=True)
mu.apply_style()
G = json.load(open(os.path.join(T, "geology_stats.json"), encoding="utf-8"))
GS = ["Granitoid", "Migmatite–gneiss", "Schist", "Quartzite", "Sedimentary"]
GLONG = {1: "Older Granite suite and charnockite", 2: "Migmatite and gneiss", 3: "Schist",
         4: "Quartzite and quartz schist", 5: "Cretaceous to Recent sediments"}
GCOL = {1: "#E8767C", 2: "#E3D88A", 3: "#78C3D8", 4: "#B9A6E0", 5: "#F4EFC8"}
UNIT_NAMES = {2: "Lower undulating plain", 3: "Incised valleys and hollows", 4: "Upper undulating plain",
              5: "Dissected slopes and spurs", 6: "High-relief hill and ridge terrain"}


def save(fig, d, name, full=False):
    for e in ("png", "pdf"):
        fig.savefig(os.path.join(d, f"{name}.{e}"), **({"bbox_inches": None} if full else {}))
    plt.close(fig)


def rd(name):
    with rasterio.open(os.path.join(P, name)) as s:
        x = s.read(1).astype("float64"); nd = s.nodata; tr = s.transform
    return np.where(x == nd, np.nan, x), tr


# ---------------------------------------------------------------- lithology map (Paper A)
z, tr = rd("dem_utm90.tif"); ext = mu.extent(tr, z.shape)
lg, _ = rd("lithgroup90.tif")
U, _ = rd("units90.tif")
hs = mu.hillshade(z, 90, vert_exag=4)
sa = gpd.read_file(os.path.join(P, "study_area.gpkg"))
xmin, ymin, xmax, ymax = sa.total_bounds; pad = 6000
FR = [xmin - pad, xmax + pad, ymin - pad, ymax + pad]
lg = np.where(np.isfinite(U) & (U > 0), lg, np.nan)   # restrict to the analysed area
gap = np.where(np.isfinite(U) & (U > 0) & ~(lg > 0), 1.0, np.nan)
fig = plt.figure(figsize=(8.3, 11.4))
ax = fig.add_axes([0.075, 0.215, 0.85, 0.745])
mu.graticule(ax, FR, step=0.5, fontsize=8)
cmap = ListedColormap([GCOL[i] for i in range(1, 6)]); norm = BoundaryNorm(np.arange(0.5, 6.5), 5)
ax.imshow(np.where(lg > 0, lg, np.nan), extent=ext, cmap=cmap, norm=norm, zorder=2, interpolation="nearest")
ax.imshow(gap, extent=ext, cmap=ListedColormap(["#d0d0d0"]), zorder=2, interpolation="nearest")
ax.imshow(hs, extent=ext, cmap="gray", vmin=0, vmax=1, alpha=0.30, zorder=3, interpolation="bilinear")
# lithological contacts
for g in range(1, 6):
    ax.contour(np.where(np.isfinite(lg), (lg == g).astype(float), np.nan), levels=[0.5], extent=ext,
               origin="upper", colors=[mu.INK], linewidths=0.25, zorder=4)
sa.boundary.plot(ax=ax, color=mu.INK, lw=1.2, zorder=6); ax.set_xlabel(""); ax.set_ylabel("")
mu.graticule(ax, FR, step=0.5, label=False)
mu.scalebar(ax); mu.north_arrow(ax, loc=(0.925, 0.86))
mu.boxed_legend(ax, [Line2D([], [], color=mu.INK, lw=1.5, label="Study area boundary"),
                     Line2D([], [], color=mu.INK, lw=0.4, label="Lithological contact")],
                loc="lower right", fontsize=8, bbox=(0.985, 0.03))
lax = fig.add_axes([0.075, 0.035, 0.85, 0.15]); lax.set_xticks([]); lax.set_yticks([])
for s in lax.spines.values(): s.set_visible(True); s.set_linewidth(1.0); s.set_color(mu.INK)
lax.text(0.02, 0.90, "Lithological group (map units)", fontsize=9.5, fontweight="bold", va="top", transform=lax.transAxes)
mem = G["group_members"]
items = [(g, f"{GLONG[g]}\n({', '.join(c for c in mem[GS[g - 1]] if c != 'QS')})") for g in range(1, 6)]
items.append((0, "Not covered by the state geological maps"))
for j, (g, txt) in enumerate(items):
    col, row = divmod(j, 3)
    x0 = 0.02 + col * 0.50; y = 0.64 - row * 0.25
    lax.add_patch(plt.Rectangle((x0, y - 0.07), 0.035, 0.14, facecolor=GCOL.get(g, "#d0d0d0"), edgecolor=mu.INK, lw=0.5,
                                transform=lax.transAxes))
    lax.text(x0 + 0.045, y, txt, fontsize=7.6, va="center", transform=lax.transAxes, linespacing=1.15)
fig.text(0.925, 0.012, "Geology: NGSA Geological and Mineral Resources Map of Ekiti State (2022, 1:250 000) and an Ondo State "
         "compilation, harmonised and resampled to 90 m. WGS 84 / UTM zone 31N.", fontsize=6.3, ha="right", va="bottom",
         color=mu.MUTED)
mu.neatline(fig)
save(fig, FA, "FigA_lithology_map", full=True)

# ---------------------------------------------------------------- terrain units vs lithology (Paper A)
B = G["basement_only"]; E = np.array(B["enrichment"])
fig, axs = plt.subplots(1, 2, figsize=(10.5, 3.9), gridspec_kw=dict(width_ratios=[1.0, 1.25]))
ax = axs[0]
im = ax.imshow(np.log2(E), cmap="RdBu_r", vmin=-2, vmax=2, aspect="auto")
for i in range(E.shape[0]):
    for j in range(E.shape[1]):
        km2 = B["matrix_km2"][i][j]
        ax.text(j, i, f"{E[i, j]:.2f}\n({km2:,.0f} km²)", ha="center", va="center", fontsize=6.5,
                color="white" if abs(np.log2(E[i, j])) > 1.2 else mu.INK)
ax.set_xticks(range(4)); ax.set_xticklabels(["Granitoid", "Migmatite–\ngneiss", "Schist", "Quartzite"])
ax.set_yticks(range(5)); ax.set_yticklabels([f"{u}  {UNIT_NAMES[u]}" for u in range(2, 7)])
for s in ax.spines.values(): s.set_visible(True)
cb = fig.colorbar(im, ax=ax, fraction=0.05, pad=0.02, ticks=[-2, -1, 0, 1, 2])
cb.ax.set_yticklabels(["0.25", "0.5", "1", "2", "4"]); cb.set_label("Enrichment (observed / expected share)")
ax.set_title("(a) Terrain units on basement lithologies", loc="left")
ax = axs[1]
kd = np.genfromtxt(os.path.join(T, "lowslope_kde_by_lithology.csv"), delimiter=",", names=True, encoding="utf-8")
names = kd.dtype.names
for nm, col, lab in [(names[1], "#C0454B", "Granitoid"), (names[2], "#8C7A1E", "Migmatite–gneiss")]:
    ax.plot(kd["elev"], kd[nm] / kd[nm].max(), color=col, lw=1.3, label=f"{lab} (n = {G['lowslope_peaks_by_group'][lab]['n']:,} cells)")
    for p_ in G["lowslope_peaks_by_group"][lab]["peaks"]:
        if p_ > 300:
            yv = np.interp(p_, kd["elev"], kd[nm] / kd[nm].max())
            ax.plot([p_], [yv], "v", color=col, ms=5)
            right = lab == "Granitoid"
            ax.annotate(f"{p_:.0f} m", (p_, yv), xytext=(7 if right else -7, 2), textcoords="offset points",
                        fontsize=7, color=col, ha="left" if right else "right", va="bottom")
for L in (347, 546):
    ax.axvline(L, color=mu.MUTED, ls=":", lw=0.9)
    ax.text(L - 6, 0.02, f"regional level {L} m", ha="right", va="bottom", fontsize=6.5, color=mu.MUTED, rotation=90)
ax.set_xlim(50, 750); ax.set_ylim(0, 1.12)
ax.set_xlabel("Elevation (m)"); ax.set_ylabel("Density of cells with slope < 2° (scaled to maximum)")
ax.legend(frameon=False, loc="upper right")
ax.set_title("(b) Low-slope elevation levels within one lithology", loc="left")
fig.tight_layout(); save(fig, FA, "FigA_lithology_terrain")

# ---------------------------------------------------------------- channels vs lithology (Paper B)
ch = np.load(os.path.join(P, "channels.npz"))
with rasterio.open(os.path.join(P, "lithgroup30.tif")) as s:
    l30 = s.read(1); t30 = s.transform
cc = ((ch["x"] - t30.c) / t30.a).astype(int); rr = ((ch["y"] - t30.f) / t30.e).astype(int)
clg = l30[rr, cc]; ksn = ch["ksn"]; good = np.isfinite(ksn) & (ch["A"] >= 1e6)
fig, axs = plt.subplots(1, 2, figsize=(10.5, 3.8))
ax = axs[0]
data = [ksn[good & (clg == g)] for g in range(1, 6)]
bp = ax.boxplot(data, widths=0.55, showfliers=False, whis=(5, 95), patch_artist=True, medianprops=dict(color=mu.INK))
for patch, g in zip(bp["boxes"], range(1, 6)):
    patch.set_facecolor(GCOL[g]); patch.set_edgecolor(mu.INK); patch.set_linewidth(0.6)
ax.set_xticks(range(1, 6)); ax.set_xticklabels(["Granitoid", "Migmatite–\ngneiss", "Schist", "Quartzite", "Sedimentary"])
for i, d in enumerate(data):
    ax.text(i + 1, -3.2, f"n = {d.size:,}", ha="center", va="top", fontsize=6.5, color=mu.MUTED)
ax.set_ylim(-5.5, 32); ax.set_ylabel(r"$k_{sn}$ (m$^{0.9}$), $\theta_{ref}$ = 0.45")
ax.axhline(0, color="#d9d9d9", lw=0.6, zorder=0)
ax.set_title("(a) Channel steepness by lithology", loc="left")
ax = axs[1]
CS = G["contact_sensitivity"]; thr = ["250", "500", "1000"]
for k_, (lab, col, off) in enumerate([("transient", "#2F6B9A", -0.13), ("stationary", "#C0454B", 0.13)]):
    xs = np.arange(3) + off
    obs = [CS[t][lab]["frac_within"] for t in thr]
    lo = [CS[t][lab]["null_q025"] for t in thr]; hi = [CS[t][lab]["null_q975"] for t in thr]; mn = [CS[t][lab]["null_mean"] for t in thr]
    ax.vlines(xs, lo, hi, color=col, lw=5, alpha=0.25)
    ax.plot(xs, mn, "_", color=col, ms=12, mew=1.2)
    nm = "Transient-type" if lab == "transient" else "Step-type"
    ax.plot(xs, obs, "o", color=col, ms=5.5, label=f"{nm} (n = {CS['500'][lab]['n']})")
    for x_, o_, t in zip(xs, obs, thr):
        ax.text(x_ + (0.06 if off > 0 else -0.06), o_, f"p = {CS[t][lab]['p_value']:.2f}", fontsize=6.5, color=col,
                ha="left" if off > 0 else "right", va="center")
ax.set_xticks(range(3)); ax.set_xticklabels(["≤ 250 m", "≤ 500 m", "≤ 1000 m"]); ax.set_xlim(-0.6, 2.6)
ax.set_xlabel("Distance to nearest lithological-group contact")
ax.set_ylabel("Fraction of knickpoints")
ax.legend(frameon=False, loc="upper left")
ax.text(0.99, 0.02, "Dots: observed. Bars: 95% range and mean (dash) of 10 000\nrandom draws of channel nodes with A ≥ 5 km².",
        transform=ax.transAxes, ha="right", va="bottom", fontsize=6.5, color=mu.MUTED)
ax.set_title("(b) Knickpoints near lithological contacts", loc="left")
fig.tight_layout(); save(fig, FB, "FigB_lithology_channels")
print("done")

# ---------------------------------------------------------------- swath profiles with lithology strip (Paper A)
from matplotlib.patches import Patch
UNIT_COL = {1: "#4A90C2", 2: "#B8DE8B", 3: "#2A9D8F", 4: "#F2D77E", 5: "#E8833A", 6: "#8C2D04"}
swaths = json.load(open(os.path.join(T, "swaths.json"), encoding="utf-8"))
swl = json.load(open(os.path.join(T, "swath_lithology.json"), encoding="utf-8"))
fig, axs = plt.subplots(2, 1, figsize=(7.4, 5.8))
for ax, (nm, sw) in zip(axs, swaths.items()):
    pr = sw["profile"]; d = np.array([p["dist_km"] for p in pr])
    ax.fill_between(d, [p["zmin"] for p in pr], [p["zmax"] for p in pr], color="#cfd8e3", lw=0, label="Min–max")
    ax.fill_between(d, [p["zp10"] for p in pr], [p["zp90"] for p in pr], color="#8fa9c4", lw=0, label="10th–90th percentile")
    ax.plot(d, [p["zmean"] for p in pr], color="#1f3b57", lw=1.4, label="Mean")
    for p in pr:
        ax.add_patch(plt.Rectangle((p["dist_km"] - 0.5, -60), 1.0, 40, color=UNIT_COL[p["unit_mode"]], lw=0))
    for p in swl[nm]:
        c = GCOL.get(p["lith_mode"], "#d0d0d0") if p["mapped_frac"] >= 0.5 else "#d0d0d0"
        ax.add_patch(plt.Rectangle((p["dist_km"] - 0.5, -110), 1.0, 40, color=c, lw=0))
    ax.text(-1.5, -40, "Unit", ha="right", va="center", fontsize=6.5)
    ax.text(-1.5, -90, "Lithology", ha="right", va="center", fontsize=6.5)
    ax.set_ylim(-115, 950); ax.set_xlim(0, d.max() + 0.5)
    s_, e_ = nm.split("–")
    ax.set_title(f"({'a' if nm.startswith('A') else 'b'}) Swath {nm} ({sw['half_width_km']*2:.0f} km wide)", loc="left", fontsize=8)
    ax.text(d.min() + 1, 900, s_, fontweight="bold"); ax.text(d.max(), 900, e_, fontweight="bold", ha="right")
    ax.set_ylabel("Elevation (m a.s.l.)"); ax.grid(axis="y", color=mu.CHART_GRID, lw=0.4)
    ax.set_yticks([0, 200, 400, 600, 800])
axs[1].set_xlabel("Distance along swath (km); strips give the modal terrain unit and lithological group in each 1 km bin")
axs[0].legend(frameon=False, ncol=3, loc="upper left", bbox_to_anchor=(0.06, 1.0))
h1 = [Patch(color=UNIT_COL[u], label=f"{u}") for u in range(1, 7)]
h2 = [Patch(color=GCOL[g], label=GS[g - 1]) for g in range(1, 6)] + [Patch(color="#d0d0d0", label="Not mapped")]
l1 = axs[1].legend(handles=h1, title="Unit", ncol=6, frameon=False, fontsize=6.5, title_fontsize=6.5, loc="upper left")
axs[1].add_artist(l1)
axs[1].legend(handles=h2, ncol=3, frameon=False, fontsize=6.5, loc="upper right", bbox_to_anchor=(0.985, 0.90))
fig.tight_layout(); save(fig, FA, "FigA_swath_lithology")
print("swath done")
