"""
09_figures_paperB.py: figures and maps for Paper B.
Usage: python -I scripts/09_figures_paperB.py --root .
"""
import argparse, os, sys, json, csv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, rasterio, geopandas as gpd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm, Normalize
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from rasterio.features import shapes
from shapely.geometry import shape
from shapely.ops import unary_union
from scipy import stats
import maputils as mu

ap = argparse.ArgumentParser(); ap.add_argument("--root", default="."); a = ap.parse_args()
R = os.path.abspath(a.root); P = os.path.join(R, "data/processed"); T = os.path.join(R, "outputs/tables")
F = os.path.join(R, os.environ.get("FIG_ROOT", "outputs/figures"), "paperB"); os.makedirs(F, exist_ok=True)
mu.apply_style()
rdcsv = lambda f: list(csv.DictReader(open(os.path.join(T, f))))
fl = lambda rows, k: np.array([float(r[k]) for r in rows])
SB = json.load(open(os.path.join(T, "paperB_summary.json"))); KS = json.load(open(os.path.join(T, "knickpoint_stats.json")))
SA = json.load(open(os.path.join(T, "paperA_summary.json")))
B = rdcsv("basins.csv"); K = rdcsv("knickpoints.csv")
rank = {int(k): v for k, v in SB["rank"].items()}
ch = np.load(os.path.join(P, "channels.npz"))
X, Y, Z, A, CHI, FD, KSN, BAS, REC, DX = (ch[k] for k in ["x", "y", "z", "A", "chi", "fd", "ksn", "basin", "rec", "dx"])

with rasterio.open(os.path.join(P, "dem_utm90.tif")) as s:
    z90 = s.read(1).astype(float); z90[z90 == s.nodata] = np.nan; t90 = s.transform
hs = mu.hillshade(z90, 90, vert_exag=4); ext = mu.extent(t90, z90.shape)
sa = gpd.read_file(os.path.join(P, "study_area.gpkg"))
xmin, ymin, xmax, ymax = sa.total_bounds; pad = 6000; FR = [xmin - pad, xmax + pad, ymin - pad, ymax + pad]

def save(fig, name):
    fig.savefig(os.path.join(F, name + ".png")); fig.savefig(os.path.join(F, name + ".pdf")); plt.close(fig)

def save_map(fig, name):
    for e_ in ("png", "pdf"):
        fig.savefig(os.path.join(F, f"{name}.{e_}"), bbox_inches=None)
    plt.close(fig)

def base(ax, label=True, alpha=1.0, fontsize=8, sides="tblr"):
    mu.graticule(ax, FR, step=0.5, label=label, fontsize=fontsize, sides=sides)
    ax.imshow(hs, extent=ext, cmap="gray", vmin=0, vmax=1, alpha=alpha, zorder=2, interpolation="bilinear")
    sa.boundary.plot(ax=ax, color=mu.INK, lw=1.2, zorder=6); ax.set_xlabel(""); ax.set_ylabel("")

def segments(mask):
    """Line segments from each channel node to its receiver."""
    i = np.where(mask & (REC >= 0))[0]; j = REC[i]
    return np.stack([np.c_[X[i], Y[i]], np.c_[X[j], Y[j]]], 1), i

# basin outlines (ranks 1..12) from the 30 m label raster, sampled every 3rd cell
with rasterio.open(os.path.join(P, "basins30.tif")) as s:
    bl = s.read(1)[::3, ::3]; tb = s.transform * rasterio.Affine.scale(3)
polys = {}
for g, v in shapes(np.where((bl > 0) & (bl <= 12), bl, 0).astype("int16"), mask=(bl > 0) & (bl <= 12), transform=tb):
    polys.setdefault(int(v), []).append(shape(g))
polys = {k: unary_union(v) for k, v in polys.items()}
bas_rank = np.array([rank.get(int(b), 0) for b in BAS])

# ---------------------------------------------------------------- Fig B1 drainage and basins
fig = plt.figure(figsize=(6.6, 8.2)); ax = fig.add_axes([0.085, 0.045, 0.83, 0.905]); base(ax, alpha=0.55)
m = A >= 10e6
seg, idx = segments(m)
lw = 0.25 + 1.6 * (np.log10(A[idx] / 1e6) - 1) / (np.log10(A.max() / 1e6) - 1)
ax.add_collection(LineCollection(seg, colors="#1f5f99", linewidths=lw, zorder=4, capstyle="round"))
for k_, poly in polys.items():
    gpd.GeoSeries([poly]).boundary.plot(ax=ax, color="#7a1f1f", lw=0.6, zorder=5)
    c = poly.representative_point()
    ax.text(c.x, c.y, f"B{k_}", fontsize=7, fontweight="bold", color="#7a1f1f", ha="center", va="center", zorder=8,
            bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.75))
for b in B:
    r_ = rank[int(b["basin"])]
    if r_ > 12: continue
    ox, oy = mu.TO_UTM.transform(float(b["outlet_lon"]), float(b["outlet_lat"]))
    coastal = b["outlet_type"].startswith("coastal")
    ax.plot(ox, oy, marker="o" if coastal else "s", ms=5, mfc="#f2c14e" if coastal else "white", mec=mu.INK, mew=0.7, zorder=9)
mu.boxed_legend(ax, [Line2D([], [], color="#1f5f99", lw=1.2, label="Channel, A ≥ 10 km²"),
                   Line2D([], [], color="#7a1f1f", lw=0.8, label="Basin ≥ 300 km² (B1–B12)"),
                   Line2D([], [], marker="o", ls="", mfc="#f2c14e", mec=mu.INK, label="Coastal / lagoonal outlet"),
                   Line2D([], [], marker="s", ls="", mfc="white", mec=mu.INK, label="Outlet on DEM boundary"),
                   Line2D([], [], color=mu.INK, lw=1.5, label="Study area boundary")],
          loc="lower right", fontsize=8, bbox=(0.985, 0.03))
ax.set_xlabel(""); ax.set_ylabel("")
mu.scalebar(ax); mu.north_arrow(ax, loc=(0.925, 0.86)); mu.neatline(fig)
save_map(fig, "FigB1_drainage_basins")

# ---------------------------------------------------------------- Fig B2 concavity
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0))
th = np.array(SB["thetas"]); cmap = plt.get_cmap("viridis")
bests = []
for bid, d in SB["disorder"].items():
    d = np.array(d); r_ = rank[int(bid)]
    axs[0].plot(th, d / d.min(), color=cmap((r_ - 1) / 11), lw=1.1)
    bests.append((r_, SB["theta_best"][bid], [float(x["area_km2"]) for x in B if x["basin"] == bid][0]))
axs[0].axvline(SB["theta_ref"], color=mu.MUTED, ls="--", lw=0.8); axs[0].text(SB["theta_ref"] + 0.01, axs[0].get_ylim()[1] * 0.98, "θref = 0.45", fontsize=6.5, va="top", color=mu.MUTED)
axs[0].set_xlabel("Concavity index, θ"); axs[0].set_ylabel("Disorder / minimum disorder")
axs[0].set_title("a  Disorder curves, basins B1–B12", loc="left", fontsize=8); axs[0].grid(axis="y", color=mu.CHART_GRID, lw=0.4)
sm = plt.cm.ScalarMappable(cmap=cmap, norm=Normalize(1, 12)); cb = fig.colorbar(sm, ax=axs[0], fraction=0.05, pad=0.02); cb.set_label("Basin rank", fontsize=7)
bests = sorted(bests)
axs[1].scatter([b[2] for b in bests], [b[1] for b in bests], s=26, color="#2a5d8f", zorder=3)
for r_, t_, ar in bests:
    axs[1].annotate(f"B{r_}", (ar, t_), xytext=(3, 3), textcoords="offset points", fontsize=6)
axs[1].axhline(SB["theta_median"], color="#c0392b", lw=0.8); axs[1].text(axs[1].get_xlim()[0] if False else 330, SB["theta_median"] + 0.015, f"median {SB['theta_median']:.2f}", fontsize=6.5, color="#c0392b")
axs[1].set_xscale("log"); axs[1].set_xticks([300, 500, 1000, 2000, 4000]); axs[1].set_xticklabels(["300", "500", "1000", "2000", "4000"]); axs[1].minorticks_off(); axs[1].set_xlabel("Basin area (km²)"); axs[1].set_ylabel("Best-fit θ"); axs[1].set_ylim(0, 0.6)
axs[1].set_title("b  Best-fit concavity", loc="left", fontsize=8); axs[1].grid(axis="y", color=mu.CHART_GRID, lw=0.4)
fig.tight_layout(); save(fig, "FigB2_concavity")

# ---------------------------------------------------------------- Fig B3 ksn and chi maps
fig = plt.figure(figsize=(12, 8.3))
axs = [fig.add_axes([0.05, 0.14, 0.43, 0.80]), fig.add_axes([0.535, 0.14, 0.43, 0.80])]
m = (A >= 5e6) & np.isfinite(KSN)
seg, idx = segments(m)
k_ = np.clip(KSN[idx], 1, 100)
base(axs[0], alpha=0.45, sides="tbl")
lc = LineCollection(seg, array=k_, cmap="plasma_r", norm=LogNorm(1, 100), linewidths=0.9, zorder=4)
axs[0].add_collection(lc)
cax = fig.add_axes([0.09, 0.07, 0.35, 0.018])
cb = fig.colorbar(lc, cax=cax, orientation="horizontal", extend="both"); cb.set_label("$k_{sn}$ (m$^{0.9}$), θ$_{ref}$ = 0.45, 1 km window", fontsize=9)
tr_ = [k for k in K if k["type"] == "transient"]; st_ = [k for k in K if k["type"] != "transient"]
h1 = axs[0].scatter(fl(tr_, "x"), fl(tr_, "y"), marker="^", s=18, c="#00a6a6", edgecolors=mu.INK, linewidths=0.4, zorder=7, label=f"Transient-type knickpoint (n = {len(tr_)})")
h2 = axs[0].scatter(fl(st_, "x"), fl(st_, "y"), marker="o", s=13, c="white", edgecolors=mu.INK, linewidths=0.5, zorder=7, label=f"Step-type knickpoint (n = {len(st_)})")
mu.boxed_legend(axs[0], [h1, h2, Line2D([], [], color=mu.INK, lw=1.5, label="Study area boundary")], loc="lower right", fontsize=8, bbox=(0.985, 0.03))
axs[0].set_title("(a) Normalised channel steepness and knickpoints", loc="left", fontsize=10, pad=16)
mu.scalebar(axs[0]); mu.north_arrow(axs[0], loc=(0.925, 0.86))
base(axs[1], alpha=0.45, sides="tbr")
mc = A >= 5e6; seg, idx = segments(mc)
lc2 = LineCollection(seg, array=CHI[idx], cmap="viridis", norm=Normalize(0, np.percentile(CHI[idx], 99)), linewidths=0.9, zorder=4)
axs[1].add_collection(lc2)
cax2 = fig.add_axes([0.575, 0.07, 0.35, 0.018])
cb = fig.colorbar(lc2, cax=cax2, orientation="horizontal", extend="max"); cb.set_label("χ (m), $A_0$ = 1 m², θ$_{ref}$ = 0.45, integrated from each basin outlet", fontsize=9)
axs[1].set_title("(b) χ integrated from each basin's own outlet", loc="left", fontsize=10, pad=16)
mu.scalebar(axs[1]); mu.north_arrow(axs[1], loc=(0.925, 0.86))
mu.neatline(fig)
save_map(fig, "FigB3_ksn_chi_maps")

# ---------------------------------------------------------------- Fig B4 profiles (B1–B4)
order = np.argsort(REC, kind="stable"); rs = REC[order]
st0 = np.searchsorted(rs, np.arange(REC.size), "left"); en0 = np.searchsorted(rs, np.arange(REC.size), "right")
def trunk(b_internal):
    o = np.where((BAS == b_internal) & (REC < 0))[0][0]; path = [o]; cur = o
    while True:
        d = order[st0[cur]:en0[cur]]
        if d.size == 0: break
        cur = d[np.argmax(A[d])]; path.append(cur)
    return np.array(path)
inv = {v: k for k, v in rank.items()}
fig, axs = plt.subplots(2, 4, figsize=(11, 5.6))
fig.subplots_adjust(left=0.07, right=0.92, top=0.94, bottom=0.08, hspace=0.38, wspace=0.25)
for j, r_ in enumerate([1, 2, 3, 4]):
    b = inv[r_]; mb = (BAS == b) & (A >= 5e6)
    t = trunk(b)
    ax = axs[0, j]
    ax.scatter(FD[mb] / 1000, Z[mb], s=0.3, color="#b5b5b5", rasterized=True, zorder=1)
    ax.plot(FD[t] / 1000, Z[t], color="#1f3b57", lw=1.2, zorder=3)
    kb = [k for k in K if int(k["basin"]) == b]
    for k in kb:
        ax.scatter(float(k["dist_km"]), float(k["z"]), marker="^" if k["type"] == "transient" else "o", s=14,
                   c="#00a6a6" if k["type"] == "transient" else "white", edgecolors=mu.INK, linewidths=0.4, zorder=4)
    bb = [x for x in B if int(x["basin"]) == b][0]
    ax.set_title(f"B{r_}  ({float(bb['area_km2']):,.0f} km², {bb['outlet_type'].split('/')[0]} outlet)", loc="left", fontsize=7.5)
    ax.set_xlabel("Distance from outlet (km)"); ax.grid(color=mu.CHART_GRID, lw=0.3)
    if j == 0: ax.set_ylabel("Elevation (m)")
    ax = axs[1, j]
    okk = mb & np.isfinite(KSN)
    sc = ax.scatter(CHI[okk], Z[okk], c=np.clip(KSN[okk], 1, 100), cmap="plasma_r", norm=LogNorm(1, 100), s=0.5, rasterized=True)
    for k in kb:
        ax.scatter(float(k["chi"]), float(k["z"]), marker="^" if k["type"] == "transient" else "o", s=14,
                   c="#00a6a6" if k["type"] == "transient" else "white", edgecolors=mu.INK, linewidths=0.4, zorder=4)
    ax.set_xlabel("χ (m)"); ax.grid(color=mu.CHART_GRID, lw=0.3)
    if j == 0: ax.set_ylabel("Elevation (m)")
for L_ in [p["elev_m"] for p in SA["lowslope_peaks"] if p["elev_m"] > 50]:
    for ax in axs.ravel(): ax.axhline(L_, color="#c0392b", lw=0.6, ls=":", zorder=0)
cb = fig.colorbar(sc, ax=axs[1, :].tolist(), fraction=0.02, pad=0.01); cb.set_label("k_sn (m^0.9)", fontsize=7)
fig.text(0.015, 0.95, "a", fontweight="bold"); fig.text(0.015, 0.47, "b", fontweight="bold")
save(fig, "FigB4_long_profiles_chi_plots")

# ---------------------------------------------------------------- Fig B5 knickpoint statistics
kd = np.loadtxt(os.path.join(T, "knickpoint_elevation_kde.csv"), delimiter=",", skiprows=1)
fig, axs = plt.subplots(1, 3, figsize=(11, 3.1))
ax = axs[0]
ax.plot(kd[:, 0], kd[:, 2], color=mu.MUTED, lw=1.2, label="Channel nodes, A ≥ 5 km²")
ax.plot(kd[:, 0], kd[:, 1], color="#00a6a6", lw=1.8, label="Transient-type knickpoints")
for L_ in KS["levels_m"]:
    ax.axvspan(L_ - KS["band_m"], L_ + KS["band_m"], color="#c0392b", alpha=0.12, lw=0)
    ax.text(L_, ax.get_ylim()[1] * 0.95, f"{L_:.0f} m", ha="center", fontsize=6.5, color="#c0392b")
ax.set_xlabel("Elevation (m a.s.l.)"); ax.set_ylabel("Probability density"); ax.set_xlim(0, 700)
ax.set_title(f"a  Elevation (Monte Carlo p = {KS['p_value']:.2f})", loc="left", fontsize=8); ax.legend(frameon=False, fontsize=6.5, loc="upper right", bbox_to_anchor=(1, 0.88))
ax = axs[1]
for typ, mk, col in [("transient", "^", "#00a6a6"), ("stationary", "o", "white")]:
    kk = [k for k in K if k["type"] == typ]
    ax.scatter(fl(kk, "area_km2"), fl(kk, "z"), marker=mk, s=12, c=col, edgecolors=mu.INK, linewidths=0.4, label="Transient-type" if typ == "transient" else "Step-type")
ax.set_xscale("log"); ax.set_xlabel("Drainage area at knickpoint (km²)"); ax.set_ylabel("Elevation (m a.s.l.)")
rho = KS["spearman_logA_z_transient"]; ax.set_title(f"b  Elevation vs area (transient ρ = {rho['rho']:.2f})", loc="left", fontsize=8)
ax.legend(frameon=False, fontsize=6.5); ax.grid(color=mu.CHART_GRID, lw=0.3)
ax = axs[2]
ca = KS["chi_alignment"]
for r_ in ca:
    ax.plot([0, 1], [r_["cv_chi"], r_["cv_h"]], color="#9aa9b8", lw=0.8, zorder=1)
ax.scatter(np.zeros(len(ca)), [r_["cv_chi"] for r_ in ca], color="#2a5d8f", s=18, zorder=2)
ax.scatter(np.ones(len(ca)), [r_["cv_h"] for r_ in ca], color="#e8833a", s=18, zorder=2)
ax.set_xticks([0, 1]); ax.set_xticklabels(["CV of χ", "CV of height\nabove outlet"]); ax.set_xlim(-0.4, 1.4)
w = KS["wilcoxon_cvh_vs_cvchi"]; ax.set_title(f"c  Alignment, {w['n']} basins (Wilcoxon p = {w['p']:.2f})", loc="left", fontsize=8)
ax.set_ylabel("Coefficient of variation"); ax.grid(axis="y", color=mu.CHART_GRID, lw=0.3)
fig.tight_layout(); save(fig, "FigB5_knickpoint_statistics")

# ---------------------------------------------------------------- Fig B6 ksn by terrain system & basin metrics
with rasterio.open(os.path.join(P, "systems90.tif")) as s:
    sysr = s.read(1)
cc = ((X - t90.c) / t90.a).astype(int); rr = ((Y - t90.f) / t90.e).astype(int)
sysn = sysr[rr.clip(0, sysr.shape[0] - 1), cc.clip(0, sysr.shape[1] - 1)]
good = np.isfinite(KSN) & (A >= 1e6)
fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.0))
data = [KSN[good & (sysn == s_)] for s_ in (1, 2, 3)]
bp = axs[0].boxplot(data, widths=0.55, showfliers=False, whis=(5, 95), patch_artist=True, medianprops=dict(color=mu.INK))
for p_, c_ in zip(bp["boxes"], ["#4A90C2", "#B8DE8B", "#E8833A"]): p_.set_facecolor(c_)
axs[0].set_xticklabels([f"I Coastal\n(n = {data[0].size:,})", f"II Plains & valleys\n(n = {data[1].size:,})", f"III Dissected upland\n(n = {data[2].size:,})"], fontsize=6.5)
axs[0].set_ylim(-5, 120); axs[0].axhline(0, color=mu.MUTED, lw=0.5)
axs[0].set_ylabel("k_sn (m^0.9)"); axs[0].set_title("a  Channel steepness by terrain system (A ≥ 1 km²)", loc="left", fontsize=8); axs[0].grid(axis="y", color=mu.CHART_GRID, lw=0.3)
big = [b for b in B if float(b["area_km2"]) >= 100 and b["ksn_mean"] not in ("", "nan")]
cols = ["#f2c14e" if b["outlet_type"].startswith("coastal") else "#2a5d8f" for b in big]
axs[1].scatter(fl(big, "relief_m"), fl(big, "ksn_mean"), c=cols, s=[4 + float(b["area_km2"]) / 40 for b in big], edgecolors=mu.INK, linewidths=0.4)
rs_ = stats.spearmanr(fl(big, "relief_m"), fl(big, "ksn_mean"))
axs[1].set_xlabel("Basin relief (m)"); axs[1].set_ylabel("Length-weighted mean k_sn")
ptxt = "p < 0.001" if rs_.pvalue < 0.001 else f"p = {rs_.pvalue:.3f}"
axs[1].set_title(f"b  Basins ≥ 100 km² (ρ = {rs_.statistic:.2f}, {ptxt}, n = {len(big)})", loc="left", fontsize=8); axs[1].grid(color=mu.CHART_GRID, lw=0.3)
axs[1].legend(handles=[Line2D([], [], marker="o", ls="", mfc="#f2c14e", mec=mu.INK, label="Coastal outlet"),
                       Line2D([], [], marker="o", ls="", mfc="#2a5d8f", mec=mu.INK, label="Boundary outlet")], frameon=False, fontsize=6.5)
fig.tight_layout(); save(fig, "FigB6_ksn_terrain_basins")
ksn_sys = {str(s_): dict(n=int(d.size), median=float(np.median(d)), p25=float(np.percentile(d, 25)), p75=float(np.percentile(d, 75)),
                       frac_nonpositive=float(np.mean(d <= 0))) for s_, d in zip((1, 2, 3), data)}
json.dump(dict(spearman_relief_ksn=dict(rho=float(rs_.statistic), p=float(rs_.pvalue), n=len(big)), ksn_by_system_A1=ksn_sys),
          open(os.path.join(T, "paperB_fig_stats.json"), "w"), indent=2)
print("Paper B figures written")
