#!/usr/bin/env bash
# Reproduces every table and figure of both papers from data/raw/Ondo_Ekiti_DEM_30m.tif.
# Total run time on a 2-core, 8 GB machine: about 15 minutes.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
bash scripts/00_download_boundaries.sh
for s in 01_prepare_dem 02_terrain_derivatives 03_cluster_diagnostics 04_classify_terrain 05_figures_paperA \
         06_flow_routing; do
  echo "== $s"; python -I "scripts/$s.py" --root "$ROOT"
done
echo "== 07_river_profiles (theta = 0.25 sensitivity run)"
python -I scripts/07_river_profiles.py --root "$ROOT" --theta_ref 0.25 --tag theta025
echo "== 07_river_profiles (main run, theta = 0.45)"
python -I scripts/07_river_profiles.py --root "$ROOT"
for s in 08_knickpoint_analysis 09_figures_paperB; do
  echo "== $s"; python -I "scripts/$s.py" --root "$ROOT"
done
# lithology tests (needs data/raw/geology/OndoEkiti_geology_mosaic_RGB_WGS84.tif and the legend CSV)
echo "== 10_geology"; python -I scripts/10_geology.py --root "$ROOT"
FIG_DPI=${FIG_DPI:-400} python -I scripts/11_figures_geology.py --root "$ROOT"
echo "Done. Tables: outputs/tables  Figures: outputs/figures"
