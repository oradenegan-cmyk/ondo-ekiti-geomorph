/**
 * 01_export_dem.js — Google Earth Engine script that extracts the 1-arc-second DEM mosaic for
 * Ondo and Ekiti States and exports it to Google Drive as a GeoTIFF.
 *
 * Paste into https://code.earthengine.google.com, set STUDY_AREA and DEM_CHOICE, press Run,
 * then start the export task from the Tasks tab. The result (Ondo_Ekiti_DEM_30m.tif) is the
 * input expected by scripts/01_prepare_dem.py (put it in data/raw/).
 *
 * Datasets (choose ONE and record the choice in the paper's Data section):
 *   'FABDEM'  bare-earth DEM with forests and buildings removed (Hawker et al., 2022)
 *             community catalogue asset: projects/sat-io/open-datasets/FABDEM
 *   'ALOS'    JAXA ALOS World 3D-30 m surface model, v3.2 (Tadono et al., 2014): JAXA/ALOS/AW3D30/V3_2
 *   'COP30'   Copernicus GLO-30 DSM: COPERNICUS/DEM/GLO30
 * Bare-earth (FABDEM) is preferred for channel and slope analysis in forested terrain.
 */

// ---------------------------------------------------------------- 1. Study area
// Option A (recommended): upload your own boundary (shapefile/GeoJSON) as a table asset and use it.
// var STUDY_AREA = ee.FeatureCollection('users/<your-username>/Ondo_Ekiti_boundary').geometry();
// Option B: FAO GAUL level-1 boundaries (coarser; check the outline against your reference map).
var gaul = ee.FeatureCollection('FAO/GAUL/2015/level1');
var STUDY_AREA = gaul.filter(ee.Filter.inList('ADM1_NAME', ['Ondo', 'Ekiti']))
                     .filter(ee.Filter.eq('ADM0_NAME', 'Nigeria'))
                     .geometry().dissolve();

// ---------------------------------------------------------------- 2. DEM choice
var DEM_CHOICE = 'FABDEM';   // 'FABDEM' | 'ALOS' | 'COP30'

function getDem(choice) {
  if (choice === 'FABDEM') {
    return ee.ImageCollection('projects/sat-io/open-datasets/FABDEM')
             .filterBounds(STUDY_AREA).mosaic().rename('Elevation')
             .setDefaultProjection('EPSG:4326', null, 30);
  }
  if (choice === 'ALOS') {
    return ee.ImageCollection('JAXA/ALOS/AW3D30/V3_2')
             .filterBounds(STUDY_AREA).select('DSM').mosaic().rename('Elevation')
             .setDefaultProjection('EPSG:4326', null, 30);
  }
  if (choice === 'COP30') {
    return ee.ImageCollection('COPERNICUS/DEM/GLO30')
             .filterBounds(STUDY_AREA).select('DEM').mosaic().rename('Elevation')
             .setDefaultProjection('EPSG:4326', null, 30);
  }
  throw new Error('Unknown DEM_CHOICE: ' + choice);
}

var dem = getDem(DEM_CHOICE).toFloat().clip(STUDY_AREA);

// ---------------------------------------------------------------- 3. Quick look
Map.centerObject(STUDY_AREA, 8);
Map.addLayer(dem, {min: 0, max: 900, palette: ['313695', '74add1', 'ffffbf', 'f46d43', 'a50026']}, 'DEM');
Map.addLayer(ee.Image().paint(STUDY_AREA, 0, 2), {palette: '000000'}, 'Study area');
print('Elevation statistics', dem.reduceRegion({
  reducer: ee.Reducer.minMax().combine(ee.Reducer.mean(), '', true),
  geometry: STUDY_AREA, scale: 90, maxPixels: 1e10
}));

// ---------------------------------------------------------------- 4. Export (1 arc-second, EPSG:4326)
Export.image.toDrive({
  image: dem.unmask(-9999),
  description: 'Ondo_Ekiti_DEM_30m_' + DEM_CHOICE,
  fileNamePrefix: 'Ondo_Ekiti_DEM_30m',
  folder: 'GEE_exports',
  region: STUDY_AREA.bounds(),
  crs: 'EPSG:4326',
  crsTransform: [1 / 3600, 0, -180, 0, -1 / 3600, 90],  // native 1-arc-second lattice
  maxPixels: 1e10,
  formatOptions: {cloudOptimized: true, noData: -9999}
});
