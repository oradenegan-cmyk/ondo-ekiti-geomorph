#!/usr/bin/env bash
# Downloads the country outlines used only for the location inset (Fig. A1).
set -euo pipefail
cd "$(dirname "$0")/../data/raw"
curl -sSL -o NGA_ADM0.geojson \
  https://media.githubusercontent.com/media/wmgeolab/geoBoundaries/main/releaseData/gbOpen/NGA/ADM0/geoBoundaries-NGA-ADM0_simplified.geojson
curl -sSL -o ne_10m_admin_0_countries.geojson \
  https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_admin_0_countries.geojson
echo "boundaries downloaded"
