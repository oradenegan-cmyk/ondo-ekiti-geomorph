"""
04_classify_terrain.py
----------------------
Builds the two-level terrain classification (Paper A) and all summary statistics.

* Ward clustering of the diagnostic sample, cut at k_units (default 6); each unit's parent at
  k_systems (default 3) is read from the same dendrogram, so the legend nests exactly.
* Every 90 m cell is assigned to the nearest unit centroid (standardised variable space).
* A single 3 x 3 majority filter removes isolated cells (minimum mapping unit ~ 0.07 km2);
  the share of re-labelled cells is reported.
* Units are re-numbered in order of increasing mean elevation within system, so numbering
  is reproducible and interpretable.
* Outputs: units90.tif, systems90.tif and tables (unit statistics, geomorphon cross-tab,
  hypsometry, low-slope elevation peaks, swath profiles).

Usage: python -I scripts/04_classify_terrain.py --root . [--k_units 6 --k_systems 3]
"""
import argparse, os, json, csv
import numpy as np, rasterio
from scipy.cluster.hierarchy import linkage, fcluster
from scipy import ndimage, stats
from scipy.signal import find_peaks
from pyproj import Transformer

ap = argparse.ArgumentParser()
ap.add_argument("--root", default="."); ap.add_argument("--k_units", type=int, default=6)
ap.add_argument("--k_systems", type=int, default=3)
a = ap.parse_args(); R = os.path.abspath(a.root)
P = os.path.join(R, "data/processed"); T = os.path.join(R, "outputs/tables")

VARS = [("dem_utm90.tif", False), ("slope90.tif", True), ("relief1km90.tif", True),
        ("tpi500_90.tif", False), ("tpi2k_90.tif", False)]
raw = {}
arrs = []
for f, lg in VARS:
    with rasterio.open(os.path.join(P, f)) as s:
        x = s.read(1).astype("float64"); nd = s.nodata; prof = s.profile; tr = s.transform
    x = np.where(x == nd, np.nan, x); raw[f] = x
    arrs.append(np.log1p(np.clip(x, 0, None)) if lg else x)
X = np.stack(arrs, -1); ok = np.isfinite(X).all(-1)
st = json.load(open(os.path.join(T, "standardisation.json")))
mu, sd = np.array(st["mean"]), np.array(st["sd"])
Z = (X[ok] - mu) / sd

idx = np.load(os.path.join(P, "ward_sample_idx.npy"))
S = Z[idx]
L = linkage(S, method="ward")
lab_u = fcluster(L, a.k_units, "maxclust"); lab_s = fcluster(L, a.k_systems, "maxclust")
parent = {u: int(np.bincount(lab_s[lab_u == u]).argmax()) for u in range(1, a.k_units + 1)}
C = np.stack([S[lab_u == u].mean(0) for u in range(1, a.k_units + 1)])

# assign all cells (chunked)
assign = np.empty(len(Z), dtype="int16")
for i in range(0, len(Z), 500000):
    z = Z[i:i + 500000]
    assign[i:i + 500000] = np.argmin(((z[:, None, :] - C[None]) ** 2).sum(-1), 1) + 1
U = np.zeros(ok.shape, "int16"); U[ok] = assign

# 3x3 majority filter (valid cells only)
def majority(U, k):
    cnt = np.stack([ndimage.uniform_filter((U == c).astype("float32"), 3, mode="constant") for c in range(1, k + 1)], -1)
    out = cnt.argmax(-1).astype("int16") + 1
    return np.where(U > 0, out, 0)
U2 = majority(U, a.k_units)
changed = float((U2 != U)[ok].mean())

# re-number: order systems by mean elevation, units by system then mean elevation
elev = raw["dem_utm90.tif"]
sys_mean = {s_: np.nanmean(elev[np.isin(U2, [u for u in parent if parent[u] == s_])]) for s_ in set(parent.values())}
sys_order = sorted(sys_mean, key=sys_mean.get)
sys_new = {s_: i + 1 for i, s_ in enumerate(sys_order)}
unit_key = sorted(range(1, a.k_units + 1), key=lambda u: (sys_new[parent[u]], np.nanmean(elev[U2 == u])))
unit_new = {u: i + 1 for i, u in enumerate(unit_key)}
Un = np.zeros_like(U2); Sn = np.zeros_like(U2)
for u in range(1, a.k_units + 1):
    Un[U2 == u] = unit_new[u]; Sn[U2 == u] = sys_new[parent[u]]
p = dict(prof, dtype="int16", nodata=0)
for name, arr in [("units90.tif", Un), ("systems90.tif", Sn)]:
    with rasterio.open(os.path.join(P, name), "w", **p) as d:
        d.write(arr, 1)

# centroids back in original units (for the legend)
cent = []
for u_old in unit_key:
    c = C[u_old - 1] * sd + mu
    cent.append(dict(unit=unit_new[u_old], system=sys_new[parent[u_old]], elev=c[0], slope=np.expm1(c[1]),
                     relief=np.expm1(c[2]), tpi500=c[3], tpi2k=c[4]))

# --- unit statistics --------------------------------------------------------
cell_km2 = 0.09 * 0.09
names = {"slope90.tif": "slope", "relief1km90.tif": "relief", "tpi500_90.tif": "tpi500", "tpi2k_90.tif": "tpi2k"}
with rasterio.open(os.path.join(P, "tri90.tif")) as s:
    tri = s.read(1).astype("float64"); tri[tri == s.nodata] = np.nan
total = (Un > 0).sum()

def hi(z):
    z = z[np.isfinite(z)]
    return (z.mean() - z.min()) / (z.max() - z.min())

rows = []
for u in range(1, a.k_units + 1):
    m = Un == u; z = elev[m]
    r = dict(unit=u, system=int(Sn[m][0]), area_km2=m.sum() * cell_km2, pct=100 * m.sum() / total,
             elev_mean=np.nanmean(z), elev_p10=np.nanpercentile(z, 10), elev_p90=np.nanpercentile(z, 90),
             slope_mean=np.nanmean(raw["slope90.tif"][m]), slope_p90=np.nanpercentile(raw["slope90.tif"][m], 90),
             relief_mean=np.nanmean(raw["relief1km90.tif"][m]), tpi500_mean=np.nanmean(raw["tpi500_90.tif"][m]),
             tpi2k_mean=np.nanmean(raw["tpi2k_90.tif"][m]), tri_mean=np.nanmean(tri[m]),
             n_patches=int(ndimage.label(m, structure=np.ones((3, 3)))[1]))
    rows.append(r)
for s_ in range(1, a.k_systems + 1):
    m = Sn == s_
    rows.append(dict(unit=f"S{s_}", system=s_, area_km2=m.sum() * cell_km2, pct=100 * m.sum() / total,
                     elev_mean=np.nanmean(elev[m]), elev_p10=np.nanpercentile(elev[m], 10),
                     elev_p90=np.nanpercentile(elev[m], 90), slope_mean=np.nanmean(raw["slope90.tif"][m]),
                     slope_p90=np.nanpercentile(raw["slope90.tif"][m], 90),
                     relief_mean=np.nanmean(raw["relief1km90.tif"][m]), tpi500_mean=np.nanmean(raw["tpi500_90.tif"][m]),
                     tpi2k_mean=np.nanmean(raw["tpi2k_90.tif"][m]), tri_mean=np.nanmean(tri[m]),
                     n_patches=int(ndimage.label(m, structure=np.ones((3, 3)))[1])))

def wcsv(name, rows):
    with open(os.path.join(T, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader()
        for r in rows:
            w.writerow({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()})
wcsv("unit_statistics.csv", rows)
wcsv("unit_centroids.csv", cent)

# --- geomorphon cross-tabulation -------------------------------------------
GM = ["flat", "peak", "ridge", "shoulder", "spur", "slope", "hollow", "footslope", "valley", "pit"]
with rasterio.open(os.path.join(P, "geomorphons90.tif")) as s:
    g = s.read(1)
ct = []
for u in range(1, a.k_units + 1):
    m = Un == u; n = m.sum()
    ct.append(dict(unit=u, **{GM[k - 1]: 100 * (g[m] == k).sum() / n for k in range(1, 11)}))
gtot = (g > 0) & (Un > 0)
ct.append(dict(unit="all", **{GM[k - 1]: 100 * (g[gtot] == k).sum() / gtot.sum() for k in range(1, 11)}))
wcsv("geomorphon_by_unit.csv", ct)
# association strength (Cramer's V) between units and geomorphons
tab = np.array([[((Un == u) & (g == k)).sum() for k in range(1, 11)] for u in range(1, a.k_units + 1)])
chi2 = stats.chi2_contingency(tab)[0]; ncell = tab.sum()
cramers_v = float(np.sqrt(chi2 / (ncell * (min(tab.shape) - 1))))

# --- hypsometry -------------------------------------------------------------
zv = elev[np.isfinite(elev)]
qs = np.linspace(0, 1, 101)
zq = np.quantile(zv, 1 - qs)  # elevation exceeded by fraction qs of the area
hyps = [dict(area_frac=float(q), rel_elev=float((z_ - zv.min()) / (zv.max() - zv.min())), elev=float(z_)) for q, z_ in zip(qs, zq)]
wcsv("hypsometric_curve.csv", hyps)

# --- low-slope elevation peaks (candidate planation levels) -----------------
slope = raw["slope90.tif"]
flat = np.isfinite(elev) & (slope < 2.0)
zf = elev[flat]
grid = np.arange(0, 700, 1.0)
rng = np.random.default_rng(1)
zs = rng.choice(zf, min(200000, zf.size), replace=False)
kde = stats.gaussian_kde(zs, bw_method=10 / zs.std())(grid)
pk, pr = find_peaks(kde, prominence=kde.max() * 0.05)
peaks = [dict(elev_m=float(grid[i]), density=float(kde[i]), prominence=float(pr["prominences"][j])) for j, i in enumerate(pk)]
np.savetxt(os.path.join(T, "lowslope_kde.csv"), np.c_[grid, kde], delimiter=",", header="elev,density", fmt="%.6g")
# all-cell KDE for comparison
za = rng.choice(zv, 200000, replace=False)
kde_all = stats.gaussian_kde(za, bw_method=10 / za.std())(grid)
np.savetxt(os.path.join(T, "allcells_kde.csv"), np.c_[grid, kde_all], delimiter=",", header="elev,density", fmt="%.6g")

# --- swath profiles -----------------------------------------------------------
to_utm = Transformer.from_crs("EPSG:4326", "EPSG:32631", always_xy=True)
SW = {"A–A′": [(4.98, 5.95), (5.30, 8.02)], "B–B′": [(4.96, 7.45), (5.98, 7.45)]}
half_w = 7500.0
H, W = elev.shape
yy, xx = np.mgrid[0:H, 0:W]
X0 = tr.c + (xx + 0.5) * tr.a; Y0 = tr.f + (yy + 0.5) * tr.e
swaths = {}
for nm, ((lo1, la1), (lo2, la2)) in SW.items():
    (x1, y1), (x2, y2) = to_utm.transform(lo1, la1), to_utm.transform(lo2, la2)
    L_ = np.hypot(x2 - x1, y2 - y1); ux, uy = (x2 - x1) / L_, (y2 - y1) / L_
    along = (X0 - x1) * ux + (Y0 - y1) * uy; across = -(X0 - x1) * uy + (Y0 - y1) * ux
    m = np.isfinite(elev) & (np.abs(across) <= half_w) & (along >= 0) & (along <= L_)
    bins = np.arange(0, L_ + 1000, 1000)
    bi = np.digitize(along[m], bins) - 1
    zz = elev[m]; uu = Un[m]
    out = []
    for b in range(len(bins) - 1):
        sel = bi == b
        if sel.sum() < 20:
            continue
        out.append(dict(dist_km=(bins[b] + 500) / 1000, zmin=float(zz[sel].min()), zmean=float(zz[sel].mean()),
                        zmax=float(zz[sel].max()), zp10=float(np.percentile(zz[sel], 10)),
                        zp90=float(np.percentile(zz[sel], 90)), unit_mode=int(np.bincount(uu[sel]).argmax())))
    swaths[nm] = dict(start=(lo1, la1), end=(lo2, la2), length_km=L_ / 1000, half_width_km=half_w / 1000, profile=out)
json.dump(swaths, open(os.path.join(T, "swaths.json"), "w"), indent=2)

summary = dict(k_units=a.k_units, k_systems=a.k_systems, parent={str(unit_new[u]): sys_new[parent[u]] for u in parent},
               majority_relabelled_frac=changed, cramers_v_units_geomorphons=cramers_v,
               hypsometric_integral=float(hi(zv)), lowslope_threshold_deg=2.0,
               lowslope_frac=float(flat.sum() / np.isfinite(elev).sum()), lowslope_peaks=peaks,
               hi_by_unit={u: float(hi(elev[Un == u])) for u in range(1, a.k_units + 1)})
json.dump(summary, open(os.path.join(T, "paperA_summary.json"), "w"), indent=2, default=float)
print(json.dumps(summary, indent=1, default=float))
for r in rows: print({k: (round(v, 2) if isinstance(v, float) else v) for k, v in r.items()})
for c in cent: print({k: (round(v, 2) if isinstance(v, float) else v) for k, v in c.items()})
