"""
03_cluster_diagnostics.py
-------------------------
Chooses the number of terrain classes (Paper A).

Variables (90 m): elevation, slope, local relief (1 km), TPI 500 m, TPI 2 km.
Slope and relief are log(1+x) transformed (right-skewed); all variables are z-scored.
Ward hierarchical clustering is run on a random sample of cells; for k = 2..10 the script
reports within-cluster sum of squares, silhouette, Calinski-Harabasz, Davies-Bouldin and
bootstrap stability (mean adjusted Rand index of nearest-centroid assignments of a fixed
evaluation set across B resamples).

Usage: python -I scripts/03_cluster_diagnostics.py --root . [--n 12000 --boot 20 --seed 42]
"""
import argparse, os, json, time
import numpy as np, rasterio
from scipy.cluster.hierarchy import linkage, fcluster
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score, adjusted_rand_score

ap = argparse.ArgumentParser()
ap.add_argument("--root", default="."); ap.add_argument("--n", type=int, default=12000)
ap.add_argument("--boot", type=int, default=20); ap.add_argument("--seed", type=int, default=42)
a = ap.parse_args(); R = os.path.abspath(a.root); P = os.path.join(R, "data/processed")
T = os.path.join(R, "outputs/tables"); os.makedirs(T, exist_ok=True)

VARS = [("dem_utm90.tif", "elev", False), ("slope90.tif", "slope", True),
        ("relief1km90.tif", "relief", True), ("tpi500_90.tif", "tpi500", False),
        ("tpi2k_90.tif", "tpi2k", False)]

def load_stack(P):
    arrs, names = [], []
    for f, n, lg in VARS:
        with rasterio.open(os.path.join(P, f)) as s:
            x = s.read(1).astype("float64"); nd = s.nodata
        x = np.where(x == nd, np.nan, x)
        arrs.append(np.log1p(np.clip(x, 0, None)) if lg else x); names.append(n)
    X = np.stack(arrs, -1)
    ok = np.isfinite(X).all(-1)
    return X, ok, names

X, ok, names = load_stack(P)
Xv = X[ok]
mu, sd = Xv.mean(0), Xv.std(0)
Z = (Xv - mu) / sd
json.dump({"vars": names, "mean": mu.tolist(), "sd": sd.tolist(), "log1p": [v[2] for v in VARS]},
          open(os.path.join(T, "standardisation.json"), "w"), indent=2)
corr = np.corrcoef(Xv.T)
np.savetxt(os.path.join(T, "variable_correlation.csv"), corr, delimiter=",", header=",".join(names), fmt="%.3f")

rng = np.random.default_rng(a.seed)
idx = rng.choice(len(Z), a.n, replace=False)
S = Z[idx]
t0 = time.time(); L = linkage(S, method="ward"); print(f"ward on {a.n}: {time.time()-t0:.1f}s")
eval_idx = rng.choice(len(Z), 20000, replace=False); E = Z[eval_idx]

def centroids(S, lab, k):
    return np.stack([S[lab == c].mean(0) for c in range(1, k + 1)])

def assign(E, C):
    return np.argmin(((E[:, None, :] - C[None]) ** 2).sum(-1), 1)

ks = range(2, 11)
ref = {k: assign(E, centroids(S, fcluster(L, k, "maxclust"), k)) for k in ks}
boot = {k: [] for k in ks}
for b in range(a.boot):
    ib = rng.choice(len(Z), a.n, replace=False); Sb = Z[ib]; Lb = linkage(Sb, method="ward")
    for k in ks:
        boot[k].append(adjusted_rand_score(ref[k], assign(E, centroids(Sb, fcluster(Lb, k, "maxclust"), k))))
    print("boot", b + 1, "done")

rows = []
for k in ks:
    lab = fcluster(L, k, "maxclust")
    C = centroids(S, lab, k)
    wss = float(sum(((S[lab == c] - C[c - 1]) ** 2).sum() for c in range(1, k + 1)))
    sil = silhouette_score(S, lab, sample_size=min(a.n, 12000), random_state=a.seed)
    rows.append(dict(k=k, wss=wss, silhouette=float(sil), ch=float(calinski_harabasz_score(S, lab)),
                     db=float(davies_bouldin_score(S, lab)), ari_mean=float(np.mean(boot[k])),
                     ari_sd=float(np.std(boot[k])), min_class_frac=float(np.bincount(lab)[1:].min() / a.n)))
    print(rows[-1])
json.dump(rows, open(os.path.join(T, "cluster_diagnostics.json"), "w"), indent=2)
import csv
with open(os.path.join(T, "cluster_diagnostics.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
np.save(os.path.join(P, "ward_sample_idx.npy"), idx)
