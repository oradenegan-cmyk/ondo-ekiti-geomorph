"""
02_terrain_derivatives.py
-------------------------
Land-surface parameters for the regional terrain classification (Paper A).

At 90 m (EPSG:32631):
  slope (deg, Horn 1981), local relief within 1 km radius (m),
  TPI at 500 m and 2 km radii (m, Weiss 2001), terrain ruggedness index (Riley et al. 1999).
At 30 m:
  geomorphons (Jasiewicz & Stepinski 2013; search 50 cells = 1.5 km, flatness 1 deg),
  then aggregated to 90 m by majority (mode) of the nine 30 m cells.

Usage: python -I scripts/02_terrain_derivatives.py --root .
"""
import argparse, os
import numpy as np
import rasterio
from scipy import ndimage
import whitebox_workflows as wbw

ap = argparse.ArgumentParser(); ap.add_argument("--root", default="."); args = ap.parse_args()
R = os.path.abspath(args.root); P = os.path.join(R, "data/processed")
ND = -9999.0

with rasterio.open(os.path.join(P, "dem_utm90.tif")) as s:
    z = s.read(1).astype("float64"); prof = s.profile
valid = z != ND
zf = np.where(valid, z, np.nan)
cs = 90.0

def write(name, arr, dtype="float32", nodata=ND):
    p = dict(prof, dtype=dtype, nodata=nodata)
    out = np.where(valid, arr, nodata).astype(dtype)
    with rasterio.open(os.path.join(P, name), "w", **p) as d:
        d.write(out, 1)

def disk(r_cells, annulus_inner=0):
    y, x = np.mgrid[-r_cells:r_cells + 1, -r_cells:r_cells + 1]
    d = np.hypot(x, y)
    return (d <= r_cells) & (d >= annulus_inner)

def nanmean_filter(a, fp):
    """Mean of valid cells within footprint fp (edge-aware)."""
    v = np.isfinite(a).astype("float64")
    s = ndimage.convolve(np.nan_to_num(a), fp.astype("float64"), mode="constant")
    n = ndimage.convolve(v, fp.astype("float64"), mode="constant")
    with np.errstate(invalid="ignore", divide="ignore"):
        return s / n

# --- slope (Horn) ---------------------------------------------------------
zp = np.where(valid, z, np.nan)
zz = np.pad(zp, 1, mode="edge")
# replace NaN neighbours by the centre value so edge slopes are computed from available data
def nb(dy, dx):
    a = zz[1 + dy:zz.shape[0] - 1 + dy, 1 + dx:zz.shape[1] - 1 + dx]
    return np.where(np.isfinite(a), a, zp)
a_, b_, c_ = nb(-1, -1), nb(-1, 0), nb(-1, 1)
d_, f_ = nb(0, -1), nb(0, 1)
g_, h_, i_ = nb(1, -1), nb(1, 0), nb(1, 1)
dzdx = ((c_ + 2 * f_ + i_) - (a_ + 2 * d_ + g_)) / (8 * cs)
dzdy = ((g_ + 2 * h_ + i_) - (a_ + 2 * b_ + c_)) / (8 * cs)
slope = np.degrees(np.arctan(np.hypot(dzdx, dzdy)))
write("slope90.tif", slope)

# --- local relief within 1 km radius --------------------------------------
fp1k = disk(int(round(1000 / cs)))
zmax = ndimage.maximum_filter(np.where(valid, z, -1e9), footprint=fp1k, mode="constant", cval=-1e9)
zmin = ndimage.minimum_filter(np.where(valid, z, 1e9), footprint=fp1k, mode="constant", cval=1e9)
relief = zmax - zmin
write("relief1km90.tif", relief)

# --- TPI at 500 m and 2 km (annulus excludes the centre cell) --------------
for r_m, name in [(500, "tpi500_90.tif"), (2000, "tpi2k_90.tif")]:
    fp = disk(int(round(r_m / cs)), annulus_inner=1)
    write(name, zf - nanmean_filter(zf, fp))

# --- TRI (Riley et al. 1999): sqrt of summed squared differences to 8 nbrs --
tri = np.zeros_like(z)
for dy in (-1, 0, 1):
    for dx in (-1, 0, 1):
        if dy == 0 and dx == 0:
            continue
        tri += (nb(dy, dx) - zp) ** 2
write("tri90.tif", np.sqrt(tri))
print("90 m derivatives written")

# --- geomorphons at 30 m, majority to 90 m --------------------------------
wbe = wbw.WbEnvironment(); wbe.verbose = False
dem30 = wbe.read_raster(os.path.join(P, "dem_utm30.tif"))
gm = wbe.geomorphons(dem30, search_distance=50, flatness_threshold=1.0, skip_distance=0,
                     output_forms=True, analyze_residuals=False)
wbe.write_raster(gm, os.path.join(P, "geomorphons30.tif"))
with rasterio.open(os.path.join(P, "geomorphons30.tif")) as s:
    g30 = s.read(1)
    g_nd = s.nodata
H, W = z.shape
blk = g30[:H * 3, :W * 3].reshape(H, 3, W, 3).transpose(0, 2, 1, 3).reshape(H, W, 9)
counts = np.stack([(blk == k).sum(-1) for k in range(1, 11)], -1)
g90 = (counts.argmax(-1) + 1).astype("int16")
g90[counts.sum(-1) == 0] = 0
write("geomorphons90.tif", g90, dtype="int16", nodata=0)
print("geomorphons written; 30 m classes present:", np.unique(g30[(g30 >= 1) & (g30 <= 10)]))
