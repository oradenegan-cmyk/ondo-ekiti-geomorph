"""
08_knickpoint_analysis.py — statistics on the knickpoint population (Paper B).

1. Robustness: share of main-run knickpoints (theta 0.45, sigma 5 m) with a counterpart
   within 1 km in (a) the sigma = 10 m run and (b) the theta = 0.25 run.
2. Elevation clustering: kernel density of transient-knickpoint elevations; Monte Carlo test
   (10 000 draws) of the fraction falling within +/- band_m of the low-slope elevation modes
   derived independently from the DEM (paper A, slope < 2 deg), against random channel nodes
   on the fitted paths.
3. chi alignment: within basins holding >= 5 transient knickpoints, coefficient of variation of
   chi, elevation and upstream distance (Royden & Perron 2013: knickpoints from a common
   base-level signal and n = 1 should align in chi).
4. ksn by terrain system (paper A units sampled at channel nodes) and by outlet type.

Usage: python -I scripts/08_knickpoint_analysis.py --root . [--band_m 30]
"""
import argparse, os, json, csv
import numpy as np, rasterio
from scipy import stats
from scipy.spatial import cKDTree

ap = argparse.ArgumentParser(); ap.add_argument("--root", default="."); ap.add_argument("--band_m", type=float, default=30)
a = ap.parse_args(); R = os.path.abspath(a.root); P = os.path.join(R, "data/processed"); T = os.path.join(R, "outputs/tables")
rd = lambda f: list(csv.DictReader(open(os.path.join(T, f))))
K = rd("knickpoints.csv"); Ks = rd("knickpoints_sigma_sens.csv"); Kt = rd("knickpoints_theta025.csv")
B = rd("basins.csv"); sumB = json.load(open(os.path.join(T, "paperB_summary.json")))
sumA = json.load(open(os.path.join(T, "paperA_summary.json")))
levels = [p["elev_m"] for p in sumA["lowslope_peaks"] if p["elev_m"] > 50]
f = lambda rows, k: np.array([float(r[k]) for r in rows])
res = {}

# 1. robustness --------------------------------------------------------------
xy = np.c_[f(K, "x"), f(K, "y")]
for name, other in [("sigma10", Ks), ("theta025", Kt)]:
    d, _ = cKDTree(np.c_[f(other, "x"), f(other, "y")]).query(xy)
    res[f"match_within_1km_{name}"] = float((d <= 1000).mean())
    tr = np.array([k["type"] == "transient" for k in K])
    res[f"match_within_1km_{name}_transient"] = float((d[tr] <= 1000).mean())

# 2. elevation clustering ----------------------------------------------------
ch = np.load(os.path.join(P, "channels.npz"))
zt = f([k for k in K if k["type"] == "transient"], "z"); zs = f([k for k in K if k["type"] != "transient"], "z")
# null: channel nodes with A >= 5 km2 (the support of the fitted paths), area-unweighted
pool = ch["z"][ch["A"] >= 5e6]
def frac_near(zv):
    return np.mean(np.any(np.abs(zv[:, None] - np.array(levels)[None]) <= a.band_m, axis=1))
obs = frac_near(zt)
rng = np.random.default_rng(11)
null = np.array([frac_near(rng.choice(pool, zt.size, replace=False)) for _ in range(10000)])
res.update(levels_m=levels, band_m=a.band_m, n_transient=int(zt.size), n_stationary=int(zs.size),
           frac_transient_near_levels=float(obs), null_mean=float(null.mean()), null_p95=float(np.percentile(null, 95)),
           p_value=float((np.sum(null >= obs) + 1) / (null.size + 1)),
           frac_stationary_near_levels=float(frac_near(zs)))
grid = np.arange(0, 700, 2.0)
kd_t = stats.gaussian_kde(zt, bw_method=20 / zt.std())(grid)
kd_p = stats.gaussian_kde(rng.choice(pool, 50000, replace=False), bw_method=20 / pool.std())(grid)
np.savetxt(os.path.join(T, "knickpoint_elevation_kde.csv"), np.c_[grid, kd_t, kd_p], delimiter=",",
           header="elev,transient_kde,channel_node_kde", fmt="%.6g")
# per-level counts
res["counts_by_level"] = {str(L): int(np.sum(np.abs(zt - L) <= a.band_m)) for L in levels}
res["transient_z_quantiles"] = np.percentile(zt, [10, 25, 50, 75, 90]).tolist()

# 2b. same test restricted to upland-outlet basins (outlet elevation > 300 m), null drawn from
#     channel nodes (A >= 5 km2) of those same basins
up = [int(b["basin"]) for b in B if float(b["outlet_z"]) > 300]
zt_up = f([k for k in K if k["type"] == "transient" and int(k["basin"]) in up], "z")
pool_up = ch["z"][(ch["A"] >= 5e6) & np.isin(ch["basin"], up)]
if zt_up.size >= 5:
    obs_up = frac_near(zt_up)
    null_up = np.array([frac_near(rng.choice(pool_up, zt_up.size, replace=False)) for _ in range(10000)])
    res["upland_outlet_basins"] = dict(basins=up, n_transient=int(zt_up.size), frac_near=float(obs_up),
                                       null_mean=float(null_up.mean()), null_p95=float(np.percentile(null_up, 95)),
                                       p_value=float((np.sum(null_up >= obs_up) + 1) / (null_up.size + 1)),
                                       z_median=float(np.median(zt_up)), z_iqr=np.percentile(zt_up, [25, 75]).tolist(),
                                       pool_z_median=float(np.median(pool_up)))
    np.savetxt(os.path.join(T, "upland_kp_vs_pool.csv"), np.r_[zt_up], delimiter=",", fmt="%.2f")

# 3. chi alignment ------------------------------------------------------------
rank = {int(k): v for k, v in sumB["rank"].items()}
rows = []
cv = lambda v: float(np.std(v) / np.mean(v))
for b in sorted({int(k["basin"]) for k in K}):
    kk = [k for k in K if int(k["basin"]) == b and k["type"] == "transient"]
    if len(kk) < 5:
        continue
    chi_, z_, d_ = f(kk, "chi"), f(kk, "z"), f(kk, "dist_km")
    zo = float([bb["outlet_z"] for bb in B if int(bb["basin"]) == b][0])
    h_ = z_ - zo   # height above the basin's own outlet (local base level), comparable with chi (0 at outlet)
    # same basin, theta = 0.25 run (chi recomputed with the basin-median concavity)
    k2 = [k for k in Kt if int(k["basin"]) == b and k["type"] == "transient"]
    cv_chi25 = cv(f(k2, "chi")) if len(k2) >= 5 else float("nan")
    rows.append(dict(basin=rank.get(b, b), n=len(kk), chi_mean=float(chi_.mean()), cv_chi=cv(chi_),
                     cv_chi_theta025=cv_chi25, n_theta025=len(k2), cv_z=cv(z_), outlet_z=zo, cv_h=cv(h_),
                     cv_dist=cv(d_), z_median=float(np.median(z_)), z_iqr=float(np.subtract(*np.percentile(z_, [75, 25])))))
# paired comparison across basins: is elevation more tightly aligned than chi?
ch_ = np.array([r["cv_h"] for r in rows]); cc = np.array([r["cv_chi"] for r in rows])
w = stats.wilcoxon(ch_, cc)
res["wilcoxon_cvh_vs_cvchi"] = dict(stat=float(w.statistic), p=float(w.pvalue), n=int(ch_.size),
                                    median_cv_h=float(np.median(ch_)), median_cv_chi=float(np.median(cc)),
                                    n_basins_cvh_lt_cvchi=int(np.sum(ch_ < cc)))
with open(os.path.join(T, "chi_alignment.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader()
    for r in rows: w.writerow({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()})
res["chi_alignment"] = rows

# 4. ksn by terrain system and outlet type ------------------------------------------
with rasterio.open(os.path.join(P, "systems90.tif")) as s:
    sysr = s.read(1); t90 = s.transform
cc = ((ch["x"] - t90.c) / t90.a).astype(int); rr = ((ch["y"] - t90.f) / t90.e).astype(int)
okc = (rr >= 0) & (rr < sysr.shape[0]) & (cc >= 0) & (cc < sysr.shape[1])
sysn = np.zeros(ch["x"].size, int); sysn[okc] = sysr[rr[okc], cc[okc]]
ksn = ch["ksn"]; good = np.isfinite(ksn) & (ch["A"] >= 5e6)
res["ksn_by_system"] = {}
for s_ in (1, 2, 3):
    v = ksn[good & (sysn == s_)]
    if v.size:
        res["ksn_by_system"][str(s_)] = dict(n=int(v.size), median=float(np.median(v)), p25=float(np.percentile(v, 25)),
                                             p75=float(np.percentile(v, 75)), p90=float(np.percentile(v, 90)))
v_all = ksn[good]
res["ksn_all"] = dict(n=int(v_all.size), median=float(np.median(v_all)), p90=float(np.percentile(v_all, 90)),
                      p99=float(np.percentile(v_all, 99)))
kw = stats.kruskal(*[ksn[good & (sysn == s_)] for s_ in (1, 2, 3) if np.any(good & (sysn == s_))])
res["ksn_kruskal_H"] = float(kw.statistic); res["ksn_kruskal_p"] = float(kw.pvalue)
# knickpoints by outlet type
otype = {int(b["basin"]): b["outlet_type"] for b in B}
res["kp_by_outlet_type"] = {}
for t_ in ("coastal/lagoonal", "boundary"):
    bs = [int(b["basin"]) for b in B if b["outlet_type"] == t_]
    kk = [k for k in K if int(k["basin"]) in bs]
    km = sum(float(b["channel_km"]) for b in B if b["outlet_type"] == t_)
    res["kp_by_outlet_type"][t_] = dict(n_basins=len(bs), channel_km=km, n_kp=len(kk),
                                        n_transient=sum(k["type"] == "transient" for k in kk),
                                        kp_per_100km=100 * len(kk) / km if km else np.nan)
# knickpoint elevation vs drainage area (transient)
At = f([k for k in K if k["type"] == "transient"], "area_km2")
rho = stats.spearmanr(np.log10(At), zt)
res["spearman_logA_z_transient"] = dict(rho=float(rho.statistic), p=float(rho.pvalue))
json.dump(res, open(os.path.join(T, "knickpoint_stats.json"), "w"), indent=2, default=float)
print(json.dumps(res, indent=1, default=float))
