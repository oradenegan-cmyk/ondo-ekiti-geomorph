"""
07_river_profiles.py — channel network, chi, concavity, ksn and knickpoints (Paper B).

Method summary
  * Channels: D8 cells with drainage area A >= 1 km2 (A_min), on the breached 30 m DEM.
  * Basins: every valid cell is labelled by the grid-edge / coastal outlet it drains to.
  * chi (Perron & Royden 2013): chi = integral (A0/A)^theta dx, A0 = 1 m2, integrated upstream
    from each basin outlet.
  * Concavity: for each basin >= 300 km2, theta in [0.10, 0.90] (step 0.05) minimising the
    disorder metric of Hergarten et al. (2016) computed on channel nodes ranked by elevation.
  * ksn = dz/dchi over a 1 km downstream window (A0 = 1 m2; units m^(2*theta)).
  * Profiles: each basin's trunk (largest-area path) plus every tributary whose area at the
    junction is >= 5 km2, followed head-ward along the largest-area donor.
  * Segmentation: each path, resampled every 150 m, is split into linear chi–z segments by
    dynamic programming (optimal partition). The number of segments k minimises
    AIC_sigma = SSE_k / sigma^2 + 2 (3k - 1), where sigma is the assumed vertical error of the DEM
    along channels (default 5 m; 10 m is run as a sensitivity test), so a break is only accepted
    when it reduces misfit by more than DEM noise can explain. Minimum segment length 10 nodes (1.5 km).
  * Knickpoints: segment breaks where ksn changes by a factor >= 1.5 (unit-free, so the rule is
    independent of theta); the AIC_sigma criterion already requires each break to exceed DEM noise.
    Type "transient" = steeper below, gentler above (ksn_down > ksn_up);
    type "stationary/step" = steeper above (ksn_up > ksn_down).

Usage: python -I scripts/07_river_profiles.py --root . [--theta_ref 0.45]
"""
import argparse, os, json, csv, time
import numpy as np, rasterio
import numba as nb
from pyproj import Transformer

ap = argparse.ArgumentParser()
ap.add_argument("--root", default="."); ap.add_argument("--theta_ref", type=float, default=0.45)
ap.add_argument("--amin_km2", type=float, default=1.0); ap.add_argument("--atrib_km2", type=float, default=5.0)
ap.add_argument("--basin_min_km2", type=float, default=300.0)
ap.add_argument("--sigma", type=float, default=5.0)
ap.add_argument("--tag", default="", help="suffix for a sensitivity run; rasters are not rewritten")
ap.add_argument("--sigma_sens", type=float, default=10.0)
a = ap.parse_args(); R = os.path.abspath(a.root); P = os.path.join(R, "data/processed"); T = os.path.join(R, "outputs/tables")
CELL = 30.0; CA = CELL * CELL
t0 = time.time()

with rasterio.open(os.path.join(P, "d8_pointer30.tif")) as s:
    ptr = s.read(1).astype(np.int32); prof = s.profile; tr = s.transform
with rasterio.open(os.path.join(P, "d8_accum30.tif")) as s:
    acc = s.read(1).astype(np.float64)
with rasterio.open(os.path.join(P, "dem30_breached.tif")) as s:
    z = s.read(1).astype(np.float64); znd = s.nodata
H, W = ptr.shape
valid = (z != znd) & (acc > 0)

DR = np.zeros(129, np.int32); DC = np.zeros(129, np.int32)
for code, (dr, dc) in {1: (-1, 1), 2: (0, 1), 4: (1, 1), 8: (1, 0), 16: (1, -1), 32: (0, -1), 64: (-1, -1), 128: (-1, 0)}.items():
    DR[code] = dr; DC[code] = dc

@nb.njit(cache=True)
def receivers(ptr, valid, DR, DC):
    H, W = ptr.shape
    rec = -np.ones(H * W, np.int64); dist = np.zeros(H * W, np.float64)
    for r in range(H):
        for c in range(W):
            i = r * W + c
            if not valid[r, c]:
                continue
            p = ptr[r, c]
            if p <= 0 or p > 128:
                continue
            rr = r + DR[p]; cc = c + DC[p]
            if rr < 0 or rr >= H or cc < 0 or cc >= W or not valid[rr, cc]:
                continue
            rec[i] = rr * W + cc
            dist[i] = 30.0 * (1.4142135623730951 if (DR[p] != 0 and DC[p] != 0) else 1.0)
    return rec, dist

rec_full, dist_full = receivers(ptr, valid, DR, DC)

# ---- basins on the full grid (process in order of decreasing accumulation) ----
flat_acc = np.where(valid, acc, -1).ravel()
order_full = np.argsort(-flat_acc, kind="stable")
nvalid = int(valid.sum()); order_full = order_full[:nvalid]

@nb.njit(cache=True)
def label_basins(order, rec):
    lab = np.zeros(rec.size, np.int32); nxt = 0
    for i in order:
        r = rec[i]
        if r < 0:
            nxt += 1; lab[i] = nxt
        else:
            lab[i] = lab[r]
    return lab, nxt

basin_full, nbas = label_basins(order_full, rec_full)
bas_cells = np.bincount(basin_full, minlength=nbas + 1)
outlet_idx = np.zeros(nbas + 1, np.int64)
outs = order_full[rec_full[order_full] < 0]
outlet_idx[basin_full[outs]] = outs
print(f"basins: {nbas}; routing done in {time.time()-t0:.0f}s")

# ---- channel subset ------------------------------------------------------------
amin_cells = a.amin_km2 * 1e6 / CA
ch = np.where((flat_acc >= amin_cells))[0]
ch = ch[np.argsort(-flat_acc[ch], kind="stable")]           # downstream -> upstream order
n = ch.size
pos = -np.ones(H * W, np.int32); pos[ch] = np.arange(n, dtype=np.int32)
rec = pos[np.where(rec_full[ch] >= 0, rec_full[ch], 0)]
rec = np.where(rec_full[ch] >= 0, rec, -1).astype(np.int64)
dx = dist_full[ch]; A = flat_acc[ch] * CA; zc = z.ravel()[ch]; bas = basin_full[ch]
rows, cols = ch // W, ch % W
X = tr.c + (cols + 0.5) * tr.a; Y = tr.f + (rows + 0.5) * tr.e
print(f"channel nodes: {n}")

@nb.njit(cache=True)
def integrate(rec, dx, A, theta):
    n = rec.size; chi = np.zeros(n); fd = np.zeros(n)
    for i in range(n):
        r = rec[i]
        if r >= 0:
            chi[i] = chi[r] + dx[i] * (1.0 / A[i]) ** theta
            fd[i] = fd[r] + dx[i]
    return chi, fd

# ---- concavity by disorder minimisation ----------------------------------------
big = [b for b in range(1, nbas + 1) if bas_cells[b] * CA / 1e6 >= a.basin_min_km2]
thetas = np.round(np.arange(0.10, 0.901, 0.05), 2)
disorder = {b: [] for b in big}
for th in thetas:
    chi_t, _ = integrate(rec, dx, A, th)
    for b in big:
        m = bas == b
        cz = chi_t[m][np.argsort(zc[m], kind="stable")]
        rngc = cz.max() - cz.min()
        disorder[b].append(float((np.abs(np.diff(cz)).sum() - rngc) / rngc))
theta_best = {b: float(thetas[int(np.argmin(disorder[b]))]) for b in big}
theta_med = float(np.median(list(theta_best.values())))
print("best-fit theta by basin:", theta_best, "median", theta_med)

theta = a.theta_ref
chi, fd = integrate(rec, dx, A, theta)

@nb.njit(cache=True)
def ksn_window(rec, fd, chi, z, L):
    n = rec.size; out = np.full(n, np.nan)
    for i in range(n):
        j = i; d = 0.0
        while rec[j] >= 0 and fd[i] - fd[j] < L:
            j = rec[j]
        if fd[i] - fd[j] >= 0.5 * L and chi[i] - chi[j] > 0:
            out[i] = (z[i] - z[j]) / (chi[i] - chi[j])
    return out

ksn = ksn_window(rec, fd, chi, zc, 1000.0)

# ---- path decomposition --------------------------------------------------------
don_order = np.argsort(rec, kind="stable"); recs_sorted = rec[don_order]
start = np.searchsorted(recs_sorted, np.arange(n), "left"); end = np.searchsorted(recs_sorted, np.arange(n), "right")

def donors(i):
    return don_order[start[i]:end[i]]

atrib_cells = a.atrib_km2 * 1e6
paths = []  # each: list of node indices from downstream end to head
stack = [(int(outlet_idx_ch), 0, -1) for outlet_idx_ch in np.where(rec < 0)[0]
         if bas_cells[bas[outlet_idx_ch]] * CA / 1e6 >= 50]
while stack:
    s0, order_, parent = stack.pop()
    path = [s0]; cur = s0
    while True:
        d = donors(cur)
        if d.size == 0:
            break
        main = d[np.argmax(A[d])]
        for t in d:
            if t != main and A[t] >= atrib_cells:
                stack.append((int(t), order_ + 1, len(paths)))
        path.append(int(main)); cur = main
    paths.append(dict(nodes=np.array(path), order=order_, parent=parent, basin=int(bas[s0])))
print(f"paths: {len(paths)}")

@nb.njit(cache=True)
def segment(x, y, kmax, mseg):
    n = x.size
    sx = np.zeros(n + 1); sy = np.zeros(n + 1); sxx = np.zeros(n + 1); sxy = np.zeros(n + 1); syy = np.zeros(n + 1)
    for i in range(n):
        sx[i + 1] = sx[i] + x[i]; sy[i + 1] = sy[i] + y[i]; sxx[i + 1] = sxx[i] + x[i] * x[i]
        sxy[i + 1] = sxy[i] + x[i] * y[i]; syy[i + 1] = syy[i] + y[i] * y[i]
    def sse(i, j):  # points i..j-1
        m = j - i
        Sx = sx[j] - sx[i]; Sy = sy[j] - sy[i]; Sxx = sxx[j] - sxx[i]; Sxy = sxy[j] - sxy[i]; Syy = syy[j] - syy[i]
        vx = Sxx - Sx * Sx / m
        if vx <= 1e-12:
            return Syy - Sy * Sy / m
        b = (Sxy - Sx * Sy / m) / vx
        return max(Syy - Sy * Sy / m - b * (Sxy - Sx * Sy / m), 0.0)
    INF = 1e300
    cost = np.full((kmax + 1, n + 1), INF); arg = -np.ones((kmax + 1, n + 1), np.int64)
    for j in range(mseg, n + 1):
        cost[1, j] = sse(0, j)
    for k in range(2, kmax + 1):
        for j in range(k * mseg, n + 1):
            best = INF; bi = -1
            for i in range((k - 1) * mseg, j - mseg + 1):
                if cost[k - 1, i] < INF:
                    c = cost[k - 1, i] + sse(i, j)
                    if c < best:
                        best = c; bi = i
            cost[k, j] = best; arg[k, j] = bi
    return cost, arg

def fit_path(nodes, sigma, spacing=150.0, kmax=8, mseg=10):
    nd = nodes                                        # nodes are stored outlet -> head
    d = fd[nd] - fd[nd[0]]
    targets = np.arange(0, d[-1], spacing)
    idx = np.unique(np.searchsorted(d, targets).clip(0, len(nd) - 1))
    nd = nd[idx]
    if nd.size < 2 * mseg:
        return None
    x = chi[nd]; y = zc[nd]
    km = min(kmax, nd.size // mseg)
    cost, arg = segment(x, y, km, mseg)
    N = nd.size; best_k, best_bic = 1, np.inf
    for k in range(1, km + 1):
        sse_k = cost[k, N]
        if not np.isfinite(sse_k) or sse_k >= 1e299:
            continue
        bic = sse_k / sigma ** 2 + 2 * (3 * k - 1)
        if bic < best_bic:
            best_bic, best_k = bic, k
    bps = []; j = N; k = best_k
    while k > 1:
        i = arg[k, j]; bps.append(i); j = i; k -= 1
    bps = sorted(bps)
    edges = [0] + bps + [N]
    segs = []
    for s_, e_ in zip(edges[:-1], edges[1:]):
        xs, ys = x[s_:e_], y[s_:e_]
        b = np.polyfit(xs, ys, 1)
        segs.append(dict(i0=s_, i1=e_, ksn=float(b[0]), intercept=float(b[1]),
                         z0=float(ys.min()), z1=float(ys.max()), chi0=float(xs.min()), chi1=float(xs.max())))
    return nd, segs

to_geo = Transformer.from_crs("EPSG:32631", "EPSG:4326", always_xy=True)

def run_segmentation(sigma):
    kps, seg_rows, path_rows = [], [], []
    for pid, p in enumerate(paths):
        out = fit_path(p["nodes"], sigma)
        if out is None:
            continue
        nd, segs = out
        path_rows.append(dict(path=pid, basin=p["basin"], order=p["order"], n_nodes=int(nd.size),
                              length_km=float((fd[nd[-1]] - fd[nd[0]]) / 1000), area_km2_mouth=float(A[nd[0]] / 1e6),
                              z_mouth=float(zc[nd[0]]), z_head=float(zc[nd[-1]]), n_segments=len(segs)))
        for si, sg in enumerate(segs):
            seg_rows.append(dict(path=pid, basin=p["basin"], seg=si, ksn=sg["ksn"], z0=sg["z0"], z1=sg["z1"],
                                 chi0=sg["chi0"], chi1=sg["chi1"],
                                 length_km=float((fd[nd[sg["i1"] - 1]] - fd[nd[sg["i0"]]]) / 1000)))
        for sd, su in zip(segs[:-1], segs[1:]):
            kd, ku = sd["ksn"], su["ksn"]
            if kd <= 0 or ku <= 0:
                ratio = np.inf
            else:
                ratio = max(kd, ku) / min(kd, ku)
            if ratio >= 1.5:
                node = nd[su["i0"]]
                lon, lat = to_geo.transform(X[node], Y[node])
                kps.append(dict(path=pid, basin=p["basin"], order=p["order"], x=float(X[node]), y=float(Y[node]),
                                lon=float(lon), lat=float(lat), z=float(zc[node]), chi=float(chi[node]),
                                dist_km=float(fd[node] / 1000), area_km2=float(A[node] / 1e6),
                                ksn_down=float(kd), ksn_up=float(ku), ratio=float(min(ratio, 99)),
                                type="transient" if kd > ku else "stationary"))
    return kps, seg_rows, path_rows

kps, seg_rows, path_rows = run_segmentation(a.sigma)
kps_s, seg_s, path_s = run_segmentation(a.sigma_sens)
print(f"knickpoints sigma={a.sigma}: {len(kps)} ({sum(k['type']=='transient' for k in kps)} transient); "
      f"sigma={a.sigma_sens}: {len(kps_s)} ({sum(k['type']=='transient' for k in kps_s)} transient)")

def wcsv(name, rows):
    if not rows:
        return
    if a.tag:
        name = name.replace(".csv", f"_{a.tag}.csv")
    with open(os.path.join(T, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader()
        for r in rows:
            w.writerow({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items()})
wcsv("knickpoints.csv", kps); wcsv("profile_segments.csv", seg_rows); wcsv("profile_paths.csv", path_rows)
wcsv("knickpoints_sigma_sens.csv", kps_s); wcsv("profile_paths_sigma_sens.csv", path_s)

# ---- basin table ---------------------------------------------------------------
zf = z.ravel()
brows = []
kp_b = {}
for k in kps:
    kp_b.setdefault(k["basin"], []).append(k)
for b in sorted(range(1, nbas + 1), key=lambda b: -bas_cells[b]):
    area = bas_cells[b] * CA / 1e6
    if area < 50:
        continue
    oi = outlet_idx[b]; orr, occ = divmod(int(oi), W)
    ox = tr.c + (occ + 0.5) * tr.a; oy = tr.f + (orr + 0.5) * tr.e
    olon, olat = to_geo.transform(ox, oy)
    m = bas == b
    kk = ksn[m]; ww = dx[m]; okk = np.isfinite(kk)
    brows.append(dict(basin=int(b), area_km2=float(area), outlet_lon=float(olon), outlet_lat=float(olat),
                      outlet_z=float(zf[oi]), outlet_type="coastal/lagoonal" if zf[oi] < 10 else "boundary",
                      z_max=float(zc[m].max()) if m.any() else np.nan,
                      theta_best=theta_best.get(b, np.nan),
                      ksn_mean=float(np.average(kk[okk], weights=ww[okk])) if okk.any() else np.nan,
                      ksn_p90=float(np.percentile(kk[okk], 90)) if okk.any() else np.nan,
                      channel_km=float(dx[m].sum() / 1000),
                      n_kp=len(kp_b.get(b, [])), n_kp_transient=sum(k["type"] == "transient" for k in kp_b.get(b, []))))
# basin hypsometric integral and relief from the full grid
lab2 = basin_full.reshape(H, W)
for r_ in brows:
    m = lab2 == r_["basin"]; zz = z[m]
    r_["relief_m"] = float(zz.max() - zz.min()); r_["hi"] = float((zz.mean() - zz.min()) / (zz.max() - zz.min()))
wcsv("basins.csv", brows)

# ---- rasters for mapping (channel ksn, chi, basin labels) ------------------------
# basin ids re-numbered by area rank for mapping (B1 = largest)
rank = {r_["basin"]: i + 1 for i, r_ in enumerate(brows)}
bl = np.zeros(H * W, np.int16)
for b, rk in rank.items():
    bl[basin_full == b] = rk
p16 = dict(prof, dtype="int16", nodata=0, compress="deflate")
if a.tag:
    json.dump(dict(theta_ref=theta, n_knickpoints=len(kps), n_transient=sum(k["type"] == "transient" for k in kps),
                   n_knickpoints_sens=len(kps_s)), open(os.path.join(T, f"paperB_summary_{a.tag}.json"), "w"), indent=2)
    raise SystemExit(0)
with rasterio.open(os.path.join(P, "basins30.tif"), "w", **p16) as d:
    d.write(bl.reshape(H, W), 1)
np.savez_compressed(os.path.join(P, "channels.npz"), x=X, y=Y, z=zc, A=A, chi=chi, fd=fd, ksn=ksn, basin=bas,
                    rec=rec, dx=dx)
json.dump(dict(theta_ref=theta, theta_best=theta_best, theta_median=theta_med, thetas=thetas.tolist(),
               disorder={str(b): v for b, v in disorder.items()}, n_channel_nodes=int(n), n_basins_total=int(nbas),
               n_paths=len(paths), n_paths_fitted=len(path_rows), n_knickpoints=len(kps),
               n_transient=sum(k["type"] == "transient" for k in kps), rank=rank, sigma=a.sigma, sigma_sens=a.sigma_sens,
               n_knickpoints_sens=len(kps_s), n_transient_sens=sum(k["type"] == "transient" for k in kps_s),
               amin_km2=a.amin_km2, atrib_km2=a.atrib_km2),
          open(os.path.join(T, "paperB_summary.json"), "w"), indent=2, default=float)
print(f"done in {time.time()-t0:.0f}s")
