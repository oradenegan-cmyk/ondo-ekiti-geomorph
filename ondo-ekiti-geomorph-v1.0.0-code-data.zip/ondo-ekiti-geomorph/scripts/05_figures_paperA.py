"""
05_figures_paperA.py — all figures and the main map for Paper A.
Usage: python -I scripts/05_figures_paperA.py --root .
"""
import argparse, os, sys, json, csv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, rasterio, geopandas as gpd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from scipy.cluster.hierarchy import linkage, dendrogram
import maputils as mu

ap = argparse.ArgumentParser(); ap.add_argument("--root", default="."); a = ap.parse_args()
R = os.path.abspath(a.root); P = os.path.join(R, "data/processed"); T = os.path.join(R, "outputs/tables")
F = os.path.join(R, "outputs/figures/paperA"); os.makedirs(F, exist_ok=True)
mu.apply_style()

UNIT_NAMES = {1: "Coastal–deltaic lowland", 2: "Lower undulating plain", 3: "Incised valleys and hollows",
              4: "Upper undulating plain", 5: "Dissected slopes and spurs", 6: "High-relief hill and ridge terrain"}
SYS_NAMES = {1: "I  Coastal lowland system", 2: "II  Plains and valleys system", 3: "III  Dissected upland system"}
UNIT_COL = {1: "#4A90C2", 2: "#B8DE8B", 3: "#2A9D8F", 4: "#F2D77E", 5: "#E8833A", 6: "#8C2D04"}
json.dump(dict(names=UNIT_NAMES, systems=SYS_NAMES, colours=UNIT_COL), open(os.path.join(T, "unit_legend.json"), "w"), indent=2)

def rd(name):
    with rasterio.open(os.path.join(P, name)) as s:
        x = s.read(1).astype("float64"); nd = s.nodata; tr = s.transform
    return np.where(x == nd, np.nan, x), tr

z, tr = rd("dem_utm90.tif"); ext = mu.extent(tr, z.shape)
U, _ = rd("units90.tif")
hs = mu.hillshade(z, 90, vert_exag=4)
sa = gpd.read_file(os.path.join(P, "study_area.gpkg"))
swaths = json.load(open(os.path.join(T, "swaths.json")))
# padded frame
xmin, ymin, xmax, ymax = sa.total_bounds
pad = 6000
FR = [xmin - pad, xmax + pad, ymin - pad, ymax + pad]

def base(ax, label=True, fontsize=8):
    mu.graticule(ax, FR, step=0.5, label=label, fontsize=fontsize)

def outline(ax, lw=1.2):
    sa.boundary.plot(ax=ax, color=mu.INK, lw=lw, zorder=6)
    ax.set_xlabel(""); ax.set_ylabel("")

def save(fig, name):
    fig.savefig(os.path.join(F, name + ".png")); fig.savefig(os.path.join(F, name + ".pdf")); plt.close(fig)

def save_map(fig, name):
    """Maps keep the full page so the neat line encloses the graticule labels."""
    for ext_ in ("png", "pdf"):
        fig.savefig(os.path.join(F, f"{name}.{ext_}"), bbox_inches=None)
    plt.close(fig)

# ---------------------------------------------------------------- Fig 1 location
fig = plt.figure(figsize=(6.6, 8.2))
ax = fig.add_axes([0.085, 0.045, 0.83, 0.905])
base(ax)
ax.imshow(hs, extent=ext, cmap="gray", vmin=0, vmax=1, zorder=2, interpolation="bilinear")
im = ax.imshow(z, extent=ext, cmap="gist_earth", vmin=0, vmax=900, alpha=0.65, zorder=3, interpolation="bilinear")
outline(ax)
for nm, sw in swaths.items():
    (x1, y1) = mu.TO_UTM.transform(*sw["start"]); (x2, y2) = mu.TO_UTM.transform(*sw["end"])
    ax.plot([x1, x2], [y1, y2], color="#111111", lw=1.2, ls=(0, (4, 2)), zorder=7)
    s_, e_ = nm.split("–")
    ax.text(x1, y1, s_, fontsize=10, fontweight="bold", ha="right", va="top", zorder=8)
    ax.text(x2, y2, e_, fontsize=10, fontweight="bold", ha="left", va="bottom", zorder=8)
mu.scalebar(ax); mu.north_arrow(ax, loc=(0.925, 0.86))
# legend panel (lower right): elevation bar + swath line, boxed
lp = ax.inset_axes([0.62, 0.035, 0.355, 0.17]); lp.set_xticks([]); lp.set_yticks([])
for s in lp.spines.values(): s.set_visible(True); s.set_linewidth(0.9); s.set_color(mu.INK)
lp.set_zorder(24); lp.patch.set_facecolor("white")
lp.text(0.06, 0.88, "Elevation (m a.s.l.)", fontsize=8, fontweight="bold", va="center", transform=lp.transAxes)
cax = lp.inset_axes([0.06, 0.60, 0.86, 0.12])
cb = fig.colorbar(im, cax=cax, orientation="horizontal"); cb.ax.tick_params(labelsize=7); cb.outline.set_linewidth(0.6)
lp.plot([0.06, 0.20], [0.24, 0.24], color="#111111", lw=1.2, ls=(0, (4, 2)), transform=lp.transAxes)
lp.text(0.24, 0.24, "Swath profile line", fontsize=8, va="center", transform=lp.transAxes)
lp.plot([0.06, 0.20], [0.09, 0.09], color=mu.INK, lw=1.5, transform=lp.transAxes)
lp.text(0.24, 0.09, "Study area boundary", fontsize=8, va="center", transform=lp.transAxes)
# inset locator (upper left, over empty ground west of the footprint)
ins = ax.inset_axes([0.03, 0.70, 0.29, 0.26])
wa = gpd.read_file(os.path.join(R, "data/raw/ne_10m_admin_0_countries.geojson"))
wa = wa[wa["CONTINENT"] == "Africa"]
ng = gpd.read_file(os.path.join(R, "data/raw/NGA_ADM0.geojson"))
wa.plot(ax=ins, color="#eeeeee", edgecolor="#bbbbbb", lw=0.3)
ng.plot(ax=ins, color="#d9d9d9", edgecolor=mu.INK, lw=0.5)
sa.to_crs(4326).plot(ax=ins, color="#c0392b", edgecolor="none")
ins.set_xlim(2.0, 15.0); ins.set_ylim(3.5, 14.3); ins.set_xticks([]); ins.set_yticks([]); ins.set_xlabel(""); ins.set_ylabel("")
for s in ins.spines.values(): s.set_visible(True); s.set_linewidth(0.9); s.set_color(mu.INK)
ins.set_zorder(24)
ins.text(8.6, 9.3, "NIGERIA", fontsize=7, ha="center", color=mu.INK)
ins.text(2.4, 4.3, "Gulf of Guinea", fontsize=6, color=mu.MUTED, style="italic")
mu.neatline(fig)
save_map(fig, "FigA1_location")

# ---------------------------------------------------------------- Fig 2 inputs
specs = [("dem_utm90.tif", "(a) Elevation (m)", "gist_earth", (0, 900)),
         ("slope90.tif", "(b) Slope (°)", "magma_r", (0, 15)),
         ("relief1km90.tif", "(c) Relief, 1 km (m)", "YlOrBr", (0, 250)),
         ("tpi500_90.tif", "(d) TPI, 500 m (m)", "RdBu_r", (-40, 40)),
         ("tpi2k_90.tif", "(e) TPI, 2 km (m)", "RdBu_r", (-80, 80))]
fig = plt.figure(figsize=(12, 4.2))
W_ = 0.172; gap = 0.019
for i, (f, t, cm, (v0, v1)) in enumerate(specs):
    ax = fig.add_axes([0.03 + i * (W_ + gap), 0.17, W_, 0.74])
    x, _ = rd(f)
    mu.graticule(ax, FR, step=1.0, label=True, fontsize=6.5, sides="bl" if i == 0 else "b")
    im = ax.imshow(x, extent=ext, cmap=cm, vmin=v0, vmax=v1, zorder=3, interpolation="nearest")
    outline(ax, 0.6); ax.set_title(t, loc="left", fontsize=9)
    if i == 0:
        mu.north_arrow(ax, loc=(0.90, 0.84), size=0.08, fontsize=9)
        mu.scalebar(ax, ticks_km=(0, 25, 50), loc=(0.03, 0.03), fontsize=6)
    cax = fig.add_axes([0.03 + i * (W_ + gap) + 0.025, 0.075, W_ - 0.05, 0.03])
    c = fig.colorbar(im, cax=cax, orientation="horizontal", extend="both"); c.ax.tick_params(labelsize=7)
mu.neatline(fig)
save_map(fig, "FigA2_input_variables")

# ---------------------------------------------------------------- Fig 3 diagnostics
dg = json.load(open(os.path.join(T, "cluster_diagnostics.json")))
k = [d["k"] for d in dg]
panels = [("wss", "a  Within-cluster sum of squares", None), ("silhouette", "b  Mean silhouette", "max"),
          ("ch", "c  Calinski–Harabasz index", "max"), ("db", "d  Davies–Bouldin index", "min"),
          ("ari_mean", "e  Bootstrap stability (ARI)", "max")]
fig, axs = plt.subplots(1, 5, figsize=(11, 2.4))
for ax, (key, t, best) in zip(axs, panels):
    y = [d[key] for d in dg]
    if key == "ari_mean":
        ax.errorbar(k, y, yerr=[d["ari_sd"] for d in dg], color="#2a5d8f", lw=1.5, marker="o", ms=4, capsize=2)
    else:
        ax.plot(k, y, color="#2a5d8f", lw=1.5, marker="o", ms=4)
    for kk in (3, 6):
        ax.axvline(kk, color=mu.MUTED, lw=0.6, ls=":")
    ax.set_title(t, loc="left", fontsize=8); ax.set_xlabel("Number of classes, k"); ax.set_xticks(k)
    ax.grid(axis="y", color=mu.CHART_GRID, lw=0.4)
fig.tight_layout(); save(fig, "FigA3_cluster_diagnostics")

# ---------------------------------------------------------------- Fig 4 dendrogram
st = json.load(open(os.path.join(T, "standardisation.json")))
X = []
for f, lg in [("dem_utm90.tif", False), ("slope90.tif", True), ("relief1km90.tif", True), ("tpi500_90.tif", False), ("tpi2k_90.tif", False)]:
    x, _ = rd(f); X.append(np.log1p(np.clip(x, 0, None)) if lg else x)
X = np.stack(X, -1); ok = np.isfinite(X).all(-1)
Zs = (X[ok] - np.array(st["mean"])) / np.array(st["sd"])
idx = np.load(os.path.join(P, "ward_sample_idx.npy"))
L = linkage(Zs[idx], method="ward")
h3 = (L[-3, 2] + L[-2, 2]) / 2; h6 = (L[-6, 2] + L[-5, 2]) / 2
fig, ax = plt.subplots(figsize=(6.5, 3.0))
dendrogram(L, truncate_mode="lastp", p=24, ax=ax, color_threshold=0, above_threshold_color="#555555",
           show_leaf_counts=True, leaf_font_size=5.5)
for h, lab in [(h3, "k = 3 (systems)"), (h6, "k = 6 (units)")]:
    ax.axhline(h, color="#c0392b", lw=0.8, ls="--"); ax.text(ax.get_xlim()[1], h, " " + lab, va="center", fontsize=7, color="#c0392b")
ax.set_ylabel("Ward linkage distance"); ax.set_xlabel("Merged cell groups (sample size in brackets)")
ax.spines["bottom"].set_visible(False)
save(fig, "FigA4_dendrogram")

# ---------------------------------------------------------------- Fig 5 main map
cmap = ListedColormap([UNIT_COL[i] for i in range(1, 7)]); norm = BoundaryNorm(np.arange(0.5, 7.5), 6)
for size, name in [((8.3, 11.4), "FigA5_terrain_units_map"), ((16.5, 23.4), "MainMap_A2_terrain_units")]:
    fs = size[0] / 8.3
    fig = plt.figure(figsize=size)
    ax = fig.add_axes([0.075, 0.215, 0.85, 0.745])
    mu.graticule(ax, FR, step=0.25 if fs > 1.5 else 0.5, fontsize=8 * fs)
    ax.imshow(U, extent=ext, cmap=cmap, norm=norm, zorder=2, interpolation="nearest")
    ax.imshow(hs, extent=ext, cmap="gray", vmin=0, vmax=1, alpha=0.38, zorder=3, interpolation="bilinear")
    outline(ax, 1.2 * fs)
    mu.scalebar(ax, fontsize=8 * fs); mu.north_arrow(ax, loc=(0.925, 0.86), fontsize=13 * fs)
    # boxed key to the study-area line (lower right, as in the thesis maps)
    mu.boxed_legend(ax, [Line2D([], [], color=mu.INK, lw=1.5 * fs, label="Study area boundary")],
                    loc="lower right", fontsize=8 * fs, bbox=(0.985, 0.03))
    # legend panel below the map, framed
    lax = fig.add_axes([0.075, 0.035, 0.85, 0.15]); lax.set_xticks([]); lax.set_yticks([])
    for s in lax.spines.values(): s.set_visible(True); s.set_linewidth(1.0); s.set_color(mu.INK)
    lax.text(0.02, 0.90, "Terrain unit", fontsize=9.5 * fs, fontweight="bold", va="top", transform=lax.transAxes)
    col_x = [0.02, 0.35, 0.68]
    for s_, units in [(1, [1]), (2, [2, 3, 4]), (3, [5, 6])]:
        x0 = col_x[s_ - 1]
        lax.text(x0, 0.70, SYS_NAMES[s_], fontsize=8 * fs, fontstyle="italic", va="center", transform=lax.transAxes)
        for j, u in enumerate(units):
            y = 0.50 - j * 0.19
            lax.add_patch(plt.Rectangle((x0, y - 0.065), 0.035, 0.13, facecolor=UNIT_COL[u], edgecolor=mu.INK, lw=0.5,
                                        transform=lax.transAxes))
            lax.text(x0 + 0.045, y, f"{u}  {UNIT_NAMES[u]}", fontsize=8 * fs, va="center", transform=lax.transAxes)
    fig.text(0.925, 0.012, "WGS 84 / UTM zone 31N (EPSG:32631); graticule in WGS 84 geographic. "
             "DEM resampled to 90 m; hillshade azimuth 315°, altitude 40°, ×4.",
             fontsize=6.5 * fs, ha="right", va="bottom", color=mu.MUTED)
    mu.neatline(fig)
    save_map(fig, name)

# ---------------------------------------------------------------- Fig 6 unit characteristics
sl, _ = rd("slope90.tif"); rl, _ = rd("relief1km90.tif"); tp, _ = rd("tpi2k_90.tif")
rng = np.random.default_rng(7)
fig, axs = plt.subplots(1, 4, figsize=(11, 2.8))
for ax, (arr, t, lim) in zip(axs, [(z, "a  Elevation (m)", None), (sl, "b  Slope (°)", (0, 30)),
                                    (rl, "c  Local relief, 1 km (m)", (0, 400)), (tp, "d  TPI, 2 km (m)", (-150, 200))]):
    data = []
    for u in range(1, 7):
        v = arr[(U == u) & np.isfinite(arr)]
        data.append(rng.choice(v, min(20000, v.size), replace=False))
    bp = ax.boxplot(data, positions=range(1, 7), widths=0.6, showfliers=False, patch_artist=True,
                    medianprops=dict(color=mu.INK, lw=1), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6),
                    boxprops=dict(lw=0.6))
    for patch, u in zip(bp["boxes"], range(1, 7)):
        patch.set_facecolor(UNIT_COL[u]); patch.set_edgecolor(mu.INK)
    ax.set_title(t, loc="left", fontsize=8); ax.set_xlabel("Terrain unit"); ax.grid(axis="y", color=mu.CHART_GRID, lw=0.4)
    if lim: ax.set_ylim(*lim)
    if "TPI" in t: ax.axhline(0, color=mu.MUTED, lw=0.6)
fig.text(0.5, -0.04, "Boxes: interquartile range and median; whiskers: 1.5 × IQR; outliers omitted. "
         "Random sample of up to 20 000 cells per unit.", ha="center", fontsize=6.5, color=mu.MUTED)
fig.tight_layout(); save(fig, "FigA6_unit_characteristics")

# ---------------------------------------------------------------- Fig 7 geomorphon composition
GM = ["flat", "peak", "ridge", "shoulder", "spur", "slope", "hollow", "footslope", "valley", "pit"]
GMC = ["#d9d9d9", "#67000d", "#cb181d", "#fc9272", "#fdd0a2", "#ece6d6", "#c6dbef", "#9ecae1", "#3182bd", "#08306b"]
rows = list(csv.DictReader(open(os.path.join(T, "geomorphon_by_unit.csv"))))
fig, ax = plt.subplots(figsize=(6.5, 3.0))
labels = [f"{r['unit']}  {UNIT_NAMES[int(r['unit'])]}" if r["unit"] != "all" else "All units" for r in rows][::-1]
left = np.zeros(len(rows))
for g, c in zip(GM, GMC):
    v = np.array([float(r[g]) for r in rows])[::-1]
    ax.barh(range(len(rows)), v, left=left, color=c, edgecolor="white", lw=0.6, label=g, height=0.72)
    left += v
ax.set_yticks(range(len(rows))); ax.set_yticklabels(labels, fontsize=7); ax.set_xlim(0, 100)
ax.set_xlabel("Share of unit area (%)")
ax.legend(ncol=5, bbox_to_anchor=(0.5, -0.22), loc="upper center", frameon=False, fontsize=6.5, handlelength=1.2)
save(fig, "FigA7_geomorphon_composition")

# ---------------------------------------------------------------- Fig 8 hypsometry + elevation density
hy = list(csv.DictReader(open(os.path.join(T, "hypsometric_curve.csv"))))
summ = json.load(open(os.path.join(T, "paperA_summary.json")))
kl = np.loadtxt(os.path.join(T, "lowslope_kde.csv"), delimiter=",", skiprows=1)
ka = np.loadtxt(os.path.join(T, "allcells_kde.csv"), delimiter=",", skiprows=1)
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0))
ax = axs[0]
ax.plot([float(r["area_frac"]) for r in hy], [float(r["rel_elev"]) for r in hy], color="#2a5d8f", lw=1.8)
ax.plot([0, 1], [1, 0], color=mu.MUTED, lw=0.6, ls=":")
ax.set_xlabel("Relative area, a/A"); ax.set_ylabel("Relative elevation, h/H"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
ax.set_title("a  Hypsometric curve", loc="left", fontsize=8)
ax.text(0.55, 0.8, f"HI = {summ['hypsometric_integral']:.3f}", fontsize=8)
ax = axs[1]
ax.plot(ka[:, 0], ka[:, 1], color=mu.MUTED, lw=1.2, label="All cells")
ax.plot(kl[:, 0], kl[:, 1], color="#c0392b", lw=1.6, label="Cells with slope < 2°")
for p in summ["lowslope_peaks"]:
    ax.annotate(f"{p['elev_m']:.0f} m", (p["elev_m"], p["density"]), xytext=(0, 8), textcoords="offset points",
                ha="center", fontsize=7, color="#c0392b")
ax.set_xlabel("Elevation (m a.s.l.)"); ax.set_ylabel("Probability density"); ax.set_xlim(0, 700)
ax.set_title("b  Elevation frequency", loc="left", fontsize=8); ax.legend(frameon=False)
ax.grid(axis="y", color=mu.CHART_GRID, lw=0.4)
fig.tight_layout(); save(fig, "FigA8_hypsometry_elevation_density")

# ---------------------------------------------------------------- Fig 9 swath profiles
fig, axs = plt.subplots(2, 1, figsize=(7.2, 5.2))
for ax, (nm, sw) in zip(axs, swaths.items()):
    pr = sw["profile"]; d = np.array([p["dist_km"] for p in pr])
    ax.fill_between(d, [p["zmin"] for p in pr], [p["zmax"] for p in pr], color="#cfd8e3", lw=0, label="Min–max")
    ax.fill_between(d, [p["zp10"] for p in pr], [p["zp90"] for p in pr], color="#8fa9c4", lw=0, label="10th–90th percentile")
    ax.plot(d, [p["zmean"] for p in pr], color="#1f3b57", lw=1.4, label="Mean")
    ymin = -60
    for p in pr:
        ax.add_patch(plt.Rectangle((p["dist_km"] - 0.5, ymin), 1.0, 40, color=UNIT_COL[p["unit_mode"]], lw=0))
    ax.set_ylim(ymin, 950); ax.set_xlim(0, d.max() + 0.5)
    s_, e_ = nm.split("–")
    ax.set_title(f"{'a' if nm.startswith('A') else 'b'}  Swath {nm} ({sw['half_width_km']*2:.0f} km wide)", loc="left", fontsize=8)
    ax.text(d.min(), 900, s_, fontweight="bold"); ax.text(d.max(), 900, e_, fontweight="bold", ha="right")
    ax.set_ylabel("Elevation (m a.s.l.)"); ax.grid(axis="y", color=mu.CHART_GRID, lw=0.4)
axs[1].set_xlabel("Distance along swath (km); colour strip = modal terrain unit per 1 km bin")
axs[0].legend(frameon=False, ncol=3, loc="upper left", bbox_to_anchor=(0.06, 1.0))
handles = [Patch(color=UNIT_COL[u], label=f"{u}") for u in range(1, 7)]
axs[1].legend(handles=handles, title="Unit", ncol=6, frameon=False, fontsize=6.5, title_fontsize=6.5, loc="upper left")
fig.tight_layout(); save(fig, "FigA9_swath_profiles")
print("Paper A figures written to", F)
