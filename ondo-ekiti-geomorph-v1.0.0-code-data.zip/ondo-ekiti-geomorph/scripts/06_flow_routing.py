"""
06_flow_routing.py — hydrological conditioning and D8 routing on the 30 m UTM grid (Paper B).

1. Least-cost depression breaching (Lindsay 2016; max breach length 100 cells = 3 km),
   followed by filling of any residual depressions so every cell drains to the grid edge.
2. D8 flow pointer (Whitebox encoding: 1 NE, 2 E, 4 SE, 8 S, 16 SW, 32 W, 64 NW, 128 N; 0 = outlet).
3. D8 flow accumulation (number of upslope cells, including the cell itself).

Usage: python -I scripts/06_flow_routing.py --root .
"""
import argparse, os, json
import numpy as np, rasterio
import whitebox_workflows as wbw

ap = argparse.ArgumentParser(); ap.add_argument("--root", default="."); a = ap.parse_args()
R = os.path.abspath(a.root); P = os.path.join(R, "data/processed")
wbe = wbw.WbEnvironment(); wbe.verbose = False
dem = wbe.read_raster(os.path.join(P, "dem_utm30.tif"))
br = wbe.hydrology.breach_depressions_least_cost(dem=dem, max_dist=100, fill_deps=True)
wbe.write_raster(br, os.path.join(P, "dem30_breached.tif"))
ptr = wbe.hydrology.d8_pointer(dem=br)
wbe.write_raster(ptr, os.path.join(P, "d8_pointer30.tif"))
acc = wbe.hydrology.d8_flow_accum(input=ptr, out_type="cells", input_is_pointer=True)
wbe.write_raster(acc, os.path.join(P, "d8_accum30.tif"))

with rasterio.open(os.path.join(P, "dem_utm30.tif")) as s:
    z0 = s.read(1); nd = s.nodata
with rasterio.open(os.path.join(P, "dem30_breached.tif")) as s:
    z1 = s.read(1)
v = z0 != nd
dz = (z1 - z0)[v]
stats = dict(cells=int(v.sum()), modified_frac=float((np.abs(dz) > 1e-3).mean()),
             lowered_frac=float((dz < -1e-3).mean()), raised_frac=float((dz > 1e-3).mean()),
             mean_abs_change_modified=float(np.abs(dz[np.abs(dz) > 1e-3]).mean()),
             max_lowering=float(dz.min()), max_raising=float(dz.max()))
json.dump(stats, open(os.path.join(R, "outputs/tables/conditioning_stats.json"), "w"), indent=2)
print(stats)
