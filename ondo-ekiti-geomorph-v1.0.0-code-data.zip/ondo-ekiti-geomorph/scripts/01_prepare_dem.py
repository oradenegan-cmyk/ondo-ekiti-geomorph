"""
01_prepare_dem.py
-----------------
Step 1 of the Ondo–Ekiti terrain workflow.

* crops the supplied 1-arc-second DEM mosaic to its valid footprint,
* reprojects it to WGS 84 / UTM zone 31N (EPSG:32631) at 30 m (bilinear),
* builds a 90 m version by block-averaging (3 x 3) for regional mapping,
* vectorises the valid-data footprint as the study-area polygon.

Usage:
    python -I scripts/01_prepare_dem.py --root .
Input:  data/raw/Ondo_Ekiti_DEM_30m.tif   (EPSG:4326, float32, nodata -9999)
Output: data/processed/dem_utm30.tif, dem_utm90.tif, study_area.gpkg
"""
import argparse, os, json
import numpy as np
import rasterio
from rasterio.warp import calculate_default_transform, reproject, Resampling
from rasterio.features import shapes
from rasterio.windows import Window
import geopandas as gpd
from shapely.geometry import shape
from shapely.ops import unary_union

ap = argparse.ArgumentParser()
ap.add_argument("--root", default=".")
args = ap.parse_args()
R = os.path.abspath(args.root)
RAW = os.path.join(R, "data/raw/Ondo_Ekiti_DEM_30m.tif")
OUT = os.path.join(R, "data/processed")
os.makedirs(OUT, exist_ok=True)
DST_CRS = "EPSG:32631"
NODATA = -9999.0

# ---- 1. crop to valid footprint -------------------------------------------
with rasterio.open(RAW) as src:
    a = src.read(1)
    valid = a != src.nodata
    # keep only the main connected footprint (stray isolated pixels are discarded)
    from scipy import ndimage
    lab, n = ndimage.label(valid, structure=np.ones((3, 3)))
    sizes = ndimage.sum(valid, lab, index=np.arange(1, n + 1))
    main = lab == (np.argmax(sizes) + 1)
    print(f"connected parts: {n}; main part holds {sizes.max() / valid.sum():.4%} of valid cells")
    a = np.where(main, a, src.nodata).astype("float32")
    del lab
    rows = np.where(main.any(1))[0]
    cols = np.where(main.any(0))[0]
    win = Window(cols.min(), rows.min(), cols.max() - cols.min() + 1, rows.max() - rows.min() + 1)
    t_crop = src.window_transform(win)
    crop = a[rows.min():rows.max() + 1, cols.min():cols.max() + 1]
    prof = src.profile.copy()
    prof.update(height=crop.shape[0], width=crop.shape[1], transform=t_crop)
    src_crs = src.crs
print("cropped geographic grid:", crop.shape)

# ---- 2. reproject to UTM 31N at 30 m ---------------------------------------
left, top = t_crop.c, t_crop.f
right = left + t_crop.a * crop.shape[1]
bottom = top + t_crop.e * crop.shape[0]
t30, w30, h30 = calculate_default_transform(src_crs, DST_CRS, crop.shape[1], crop.shape[0],
                                            left, bottom, right, top, resolution=30)
# snap origin to a 90 m lattice so the 30 m and 90 m grids nest exactly
x0 = np.floor(t30.c / 90) * 90
y0 = np.ceil(t30.f / 90) * 90
w30 = int(np.ceil((t30.c + w30 * 30 - x0) / 90) * 3)
h30 = int(np.ceil((y0 - (t30.f - h30 * 30)) / 90) * 3)
t30 = rasterio.Affine(30, 0, x0, 0, -30, y0)
dem30 = np.full((h30, w30), NODATA, dtype="float32")
reproject(crop, dem30, src_transform=t_crop, src_crs=src_crs, src_nodata=NODATA,
          dst_transform=t30, dst_crs=DST_CRS, dst_nodata=NODATA, resampling=Resampling.bilinear)
p30 = dict(driver="GTiff", dtype="float32", count=1, crs=DST_CRS, transform=t30, width=w30,
           height=h30, nodata=NODATA, compress="deflate", tiled=True, blockxsize=512, blockysize=512,
           BIGTIFF="IF_SAFER")
with rasterio.open(os.path.join(OUT, "dem_utm30.tif"), "w", **p30) as dst:
    dst.write(dem30, 1)
print("UTM 30 m grid:", dem30.shape)

# ---- 3. 90 m block mean (all nine cells must be valid) ---------------------
H, W = h30 // 3, w30 // 3
blk = dem30[:H * 3, :W * 3].reshape(H, 3, W, 3)
ok = (blk != NODATA).all(axis=(1, 3))
dem90 = np.where(ok, blk.mean(axis=(1, 3)), NODATA).astype("float32")
t90 = rasterio.Affine(90, 0, x0, 0, -90, y0)
p90 = dict(p30, transform=t90, width=W, height=H)
with rasterio.open(os.path.join(OUT, "dem_utm90.tif"), "w", **p90) as dst:
    dst.write(dem90, 1)
print("UTM 90 m grid:", dem90.shape)

# ---- 4. study-area polygon from the 90 m valid mask ------------------------
m = (dem90 != NODATA).astype("uint8")
polys = [shape(g) for g, v in shapes(m, mask=m == 1, transform=t90) if v == 1]
poly = unary_union(polys)
# keep the largest part plus any part > 5 km2; fill interior holes < 5 km2
from shapely.geometry import Polygon, MultiPolygon
parts = list(poly.geoms) if isinstance(poly, MultiPolygon) else [poly]
parts = [Polygon(p.exterior, [h for h in p.interiors if Polygon(h).area > 5e6]) for p in parts if p.area > 5e6]
sa = gpd.GeoDataFrame({"name": ["Ondo-Ekiti DEM footprint"]}, geometry=[unary_union(parts)], crs=DST_CRS)
sa.to_file(os.path.join(OUT, "study_area.gpkg"), driver="GPKG")
v30 = dem30[dem30 != NODATA]
summary = dict(area_km2=round(sa.area.iloc[0] / 1e6, 1), cells30=int(v30.size),
               zmin=float(v30.min()), zmax=float(v30.max()), zmean=float(v30.mean()),
               zmedian=float(np.median(v30)))
json.dump(summary, open(os.path.join(R, "outputs/tables/dem_summary.json"), "w"), indent=2)
print(summary)
