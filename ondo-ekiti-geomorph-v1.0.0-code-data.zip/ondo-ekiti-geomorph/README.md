# ondo-ekiti-geomorph

Code and derived data for two companion papers on the terrain of Ondo and Ekiti States, south-western Nigeria:

- **Paper A** — *Terrain units of Ondo and Ekiti States, south-western Nigeria: a hierarchical, DEM-based geomorphological map* (target: *Journal of Maps*).
- **Paper B** — *River profiles of Ondo and Ekiti States: low concavity and a heterogeneous knickpoint population on a stepped tropical landscape* (river-profile, χ and knickpoint analysis).

Author: Adenegan Opeyemi Rapheal ([ORCID 0009-0004-0305-3420](https://orcid.org/0009-0004-0305-3420)), Department of Geography, Obafemi Awolowo University, Ile-Ife, Nigeria.

Every number, table and figure in both papers is produced by the scripts here from one input DEM. Nothing is entered by hand.

## Repository layout

```
ondo-ekiti-geomorph/
├── gee/01_export_dem.js           Earth Engine script: extract and export the 1″ DEM for the two states
├── scripts/
│   ├── 00_download_boundaries.sh  country outlines for the location inset
│   ├── 01_prepare_dem.py          crop, reproject to UTM 31N (30 m), block-average to 90 m, footprint polygon
│   ├── 02_terrain_derivatives.py  slope, 1 km relief, TPI 500 m / 2 km, TRI (90 m); geomorphons (30 m → 90 m)
│   ├── 03_cluster_diagnostics.py  Ward clustering, k = 2..10 validity indices, bootstrap stability (ARI)
│   ├── 04_classify_terrain.py     two-level classification (3 systems / 6 units) and all Paper A tables
│   ├── 05_figures_paperA.py       Paper A figures and the A2 main map
│   ├── 06_flow_routing.py         least-cost breaching, D8 pointer and accumulation (30 m)
│   ├── 07_river_profiles.py       basins, χ, concavity (disorder), ksn, path segmentation, knickpoints
│   ├── 08_knickpoint_analysis.py  robustness, elevation clustering (Monte Carlo), χ alignment, ksn summaries
│   ├── 09_figures_paperB.py       Paper B figures and maps
│   └── maputils.py                cartographic helpers (graticule, north arrow, scale bar, legends)
├── data/raw/                      input DEM (not in git; see below)
├── data/processed/                rebuildable rasters (only the small products are kept in git)
├── outputs/tables/                every table and statistic used in the papers (CSV / JSON)
├── outputs/figures/paperA|paperB  figures as 400 dpi PNG and vector PDF
├── run_all.sh                     reproduces everything in order
├── requirements.txt, environment.yml
└── CITATION.cff, LICENSE
```

## 1. Get the DEM

1. Open `gee/01_export_dem.js` in the [Earth Engine Code Editor](https://code.earthengine.google.com).
2. Set `STUDY_AREA` (upload your boundary as an asset, or use the FAO GAUL default) and `DEM_CHOICE` (`'FABDEM'` recommended; `'ALOS'` or `'COP30'` for comparison).
3. Run, then start the export task in the *Tasks* tab. Download `Ondo_Ekiti_DEM_30m.tif` from Google Drive into `data/raw/`.

The file must be EPSG:4326, float32, with nodata −9999 outside the study area. **Record which product you exported**: the papers' Data sections name it.

## 2. Install

```bash
conda env create -f environment.yml && conda activate ondo-ekiti-geomorph
# or: python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
```

`whitebox-workflows` provides the WhiteboxTools engine as a Python wheel; no separate binary download is needed.

## 3. Run

```bash
bash run_all.sh            # about 15 minutes on 2 cores / 8 GB RAM
```

Or step by step: `python -I scripts/01_prepare_dem.py --root .`, then 02 … 09 in order. Scripts 07 and 08 expect the θ = 0.25 sensitivity run (`--theta_ref 0.25 --tag theta025`) to exist before the main run; `run_all.sh` does this.

## 4. Key parameters (and where to change them)

| Step | Parameter | Value | Script / argument |
| --- | --- | --- | --- |
| Grids | analysis CRS; cell sizes | EPSG:32631; 30 m and 90 m | 01 |
| Terrain | relief window; TPI radii | 1 km; 500 m and 2 km | 02 |
| Geomorphons | search; flatness | 50 cells (1.5 km); 1° | 02 |
| Clustering | sample; seed; bootstrap | 12 000 cells; 42; 20 | 03 `--n --seed --boot` |
| Classification | systems / units | 3 / 6 | 04 `--k_systems --k_units` |
| Routing | max breach length | 100 cells (3 km) | 06 |
| Channels | A_min; tributary threshold | 1 km²; 5 km² | 07 `--amin_km2 --atrib_km2` |
| χ | A₀; θ_ref | 1 m²; 0.45 | 07 `--theta_ref` |
| Segmentation | DEM error σ; min. segment | 5 m (10 m sensitivity); 1.5 km | 07 `--sigma --sigma_sens` |
| Knickpoints | ksn ratio | ≥ 1.5 | 07 |
| Elevation test | band around levels | ±30 m; 10 000 draws | 08 `--band_m` |

## 5. Outputs used in the papers

| File | Content |
| --- | --- |
| `outputs/tables/cluster_diagnostics.csv` | WSS, silhouette, CH, DB, ARI for k = 2–10 |
| `outputs/tables/unit_statistics.csv` | area and morphometry of units and systems (Paper A Table 2) |
| `outputs/tables/geomorphon_by_unit.csv` | geomorphon composition per unit |
| `outputs/tables/paperA_summary.json` | HI, low-slope peaks, Cramér's V, majority-filter share |
| `outputs/tables/basins.csv` | basin metrics (Paper B Table 2) |
| `outputs/tables/knickpoints.csv` | every knickpoint with location, elevation, χ, area, ksn below/above, type |
| `outputs/tables/knickpoint_stats.json` | robustness, Monte Carlo and alignment statistics |
| `data/processed/units90.tif`, `systems90.tif` | the terrain-unit and terrain-system rasters (90 m) |

## Licence

Code: MIT. Derived data in `outputs/` and `data/processed/`: CC BY 4.0. Cite via `CITATION.cff` or the Zenodo DOI.
